// Volume Master Content Script - Enhanced Audio Quality
// Advanced audio processing with quality preservation

(function() {
    let volumeMultiplier = 1.0;
    let audioContext = null;
    let mediaElements = new Map();
    
    // Audio processing nodes for quality enhancement
    let compressor = null;
    let limiter = null;
    let masterGain = null;

    // Initialize advanced audio boost system with quality preservation
    function initAudioBoost() {
        try {
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
            
            // Create a compressor to prevent distortion at high volumes
            compressor = audioContext.createDynamicsCompressor();
            compressor.threshold.value = -24; // Start compression at -24dB
            compressor.knee.value = 30; // Smooth compression curve
            compressor.ratio.value = 12; // Strong compression ratio
            compressor.attack.value = 0.003; // Fast attack (3ms)
            compressor.release.value = 0.25; // 250ms release
            
            // Create a limiter to prevent clipping
            limiter = audioContext.createDynamicsCompressor();
            limiter.threshold.value = -3; // Hard limit at -3dB
            limiter.knee.value = 0; // Hard knee for limiting
            limiter.ratio.value = 20; // Very high ratio for limiting
            limiter.attack.value = 0.001; // Very fast attack
            limiter.release.value = 0.1; // Fast release
            
            // Master gain control
            masterGain = audioContext.createGain();
            
            // Connect processing chain: compressor -> limiter -> masterGain -> output
            compressor.connect(limiter);
            limiter.connect(masterGain);
            masterGain.connect(audioContext.destination);
            
            console.log("Advanced audio processing initialized");
            
        } catch (e) {
            console.log("Web Audio API not available:", e);
        }
    }

    // Apply volume with quality preservation to a media element
    function applyVolumeToElement(media) {
        if (!media) return;

        // For volume <= 100%, use native volume only
        if (volumeMultiplier <= 1.0) {
            media.volume = volumeMultiplier;
            
            // Disconnect Web Audio if it was connected
            if (mediaElements.has(media)) {
                const data = mediaElements.get(media);
                if (data.source) {
                    try {
                        data.source.disconnect();
                        data.preGain.disconnect();
                    } catch (e) {}
                }
                mediaElements.delete(media);
            }
            return;
        }

        // For volume > 100%, use advanced Web Audio processing
        if (!audioContext) {
            initAudioBoost();
        }

        if (!audioContext) {
            media.volume = 1.0;
            return;
        }

        try {
            let data = mediaElements.get(media);
            
            if (!data) {
                // Create new audio routing with quality enhancement
                const source = audioContext.createMediaElementSource(media);
                const preGain = audioContext.createGain();
                
                // Connect: source -> preGain -> compressor (-> limiter -> masterGain -> output)
                source.connect(preGain);
                preGain.connect(compressor);
                
                data = { source, preGain };
                mediaElements.set(media, data);
                
                console.log("Audio boost applied with quality preservation");
            }

            // Set native volume to maximum
            media.volume = 1.0;
            
            // Calculate optimal gain with quality preservation
            // Use logarithmic scaling for more natural volume increase
            const baseGain = Math.pow(volumeMultiplier, 0.85); // Slightly reduce extreme boosts
            
            // Apply makeup gain if needed for very high boosts
            let finalGain = baseGain;
            if (volumeMultiplier > 3.0) {
                // For extreme boosts, add makeup gain with soft limiting
                const makeupGain = 1 + (volumeMultiplier - 3.0) * 0.3;
                finalGain = baseGain * makeupGain;
            }
            
            // Set the pre-gain (before compression)
            data.preGain.gain.setTargetAtTime(finalGain, audioContext.currentTime, 0.05);
            
            // Adjust master gain for overall balance
            if (masterGain) {
                masterGain.gain.setTargetAtTime(0.95, audioContext.currentTime, 0.05);
            }

        } catch (e) {
            console.log("Could not boost audio:", e);
            media.volume = 1.0;
        }
    }

    // Apply volume to all media elements
    function applyVolumeToAll() {
        const allMedia = document.querySelectorAll('audio, video');
        allMedia.forEach(media => {
            applyVolumeToElement(media);
        });
    }

    // Listen for volume changes from background
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'set_volume') {
            volumeMultiplier = request.volume / 100;
            applyVolumeToAll();
            sendResponse({ success: true });
            return true;
        }
        
        // Toggle quality mode
        if (request.action === 'set_quality_mode') {
            updateQualitySettings(request.mode);
            applyVolumeToAll();
            sendResponse({ success: true });
            return true;
        }
    });

    // Update quality settings based on mode
    function updateQualitySettings(mode) {
        if (!compressor || !limiter) return;
        
        if (mode === 'maximum_quality') {
            // Maximum quality - gentle compression, preserve dynamics
            compressor.threshold.value = -30;
            compressor.ratio.value = 8;
            compressor.attack.value = 0.005;
            compressor.release.value = 0.3;
            limiter.threshold.value = -1;
            
        } else if (mode === 'balanced') {
            // Balanced - moderate compression
            compressor.threshold.value = -24;
            compressor.ratio.value = 12;
            compressor.attack.value = 0.003;
            compressor.release.value = 0.25;
            limiter.threshold.value = -3;
            
        } else if (mode === 'maximum_loudness') {
            // Maximum loudness - aggressive compression
            compressor.threshold.value = -18;
            compressor.ratio.value = 16;
            compressor.attack.value = 0.001;
            compressor.release.value = 0.15;
            limiter.threshold.value = -0.5;
        }
    }

    // Observer for dynamically added media elements
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            mutation.addedNodes.forEach((node) => {
                if (node.nodeName === 'VIDEO' || node.nodeName === 'AUDIO') {
                    applyVolumeToElement(node);
                } else if (node.querySelectorAll) {
                    const media = node.querySelectorAll('audio, video');
                    media.forEach(m => applyVolumeToElement(m));
                }
            });
        });
    });

    // Start observing when DOM is ready
    if (document.body) {
        observer.observe(document.body, { childList: true, subtree: true });
    } else {
        document.addEventListener('DOMContentLoaded', () => {
            observer.observe(document.body, { childList: true, subtree: true });
        });
    }

    // Apply to existing media elements
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', applyVolumeToAll);
    } else {
        applyVolumeToAll();
    }

    // Reapply volume when media starts playing
    document.addEventListener('play', (e) => {
        if (e.target.tagName === 'VIDEO' || e.target.tagName === 'AUDIO') {
            setTimeout(() => applyVolumeToElement(e.target), 100);
        }
    }, true);
    
    // Handle when media is loaded
    document.addEventListener('loadedmetadata', (e) => {
        if (e.target.tagName === 'VIDEO' || e.target.tagName === 'AUDIO') {
            applyVolumeToElement(e.target);
        }
    }, true);

})();