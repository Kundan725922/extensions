// Store volume settings for all tabs
let tabSettings = {};
let priorityTabId = null;

// Listen for messages from popup and content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    
    // Update volume for a specific tab
    if (request.action === 'update_volume') {
        const tabId = request.tabId;
        tabSettings[tabId] = {
            volume: request.volume,
            timestamp: Date.now()
        };
        
        // Apply volume to the tab
        applyVolumeToTab(tabId, request.volume);
        sendResponse({ success: true });
        return true;
    }
    
    // Set priority tab
    if (request.action === 'set_priority') {
        priorityTabId = request.tabId;
        
        // Update all tabs based on priority
        updateAllTabsVolume();
        sendResponse({ success: true });
        return true;
    }
    
    // Clear priority
    if (request.action === 'clear_priority') {
        priorityTabId = null;
        updateAllTabsVolume();
        sendResponse({ success: true });
        return true;
    }
    
    // Get current tab settings
    if (request.action === 'get_settings') {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
                const tabId = tabs[0].id;
                const settings = tabSettings[tabId] || { volume: 100 };
                sendResponse({ 
                    settings: settings,
                    isPriority: priorityTabId === tabId,
                    priorityTabId: priorityTabId
                });
            }
        });
        return true;
    }
    
    // Get all tabs with audio
    if (request.action === 'get_audio_tabs') {
        chrome.tabs.query({}, (tabs) => {
            const audioTabs = tabs.filter(tab => tab.audible || tabSettings[tab.id]);
            sendResponse({ 
                tabs: audioTabs.map(tab => ({
                    id: tab.id,
                    title: tab.title,
                    url: tab.url,
                    audible: tab.audible,
                    volume: tabSettings[tab.id]?.volume || 100,
                    isPriority: priorityTabId === tab.id
                }))
            });
        });
        return true;
    }
    
    return true;
});


// Apply volume to a specific tab
function applyVolumeToTab(tabId, volume) {
    chrome.tabs.get(tabId, (tab) => {
        if (chrome.runtime.lastError || !tab) {
            return;
        }
        
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: setVolume,
            args: [volume]
        }).catch(err => {
            console.log("Could not inject script:", err);
        });
    });
}


// Function to inject into page
function setVolume(volumePercent) {
    const volumeMultiplier = volumePercent / 100;
    
    // Apply to all audio and video elements
    const mediaElements = document.querySelectorAll('audio, video');
    mediaElements.forEach(media => {
        media.volume = Math.min(1.0, volumeMultiplier);
        
        // For volumes > 100%, use Web Audio API
        if (volumeMultiplier > 1.0 && !media.audioBoostApplied) {
            try {
                const audioContext = new (window.AudioContext || window.webkitAudioContext)();
                const source = audioContext.createMediaElementSource(media);
                const gainNode = audioContext.createGain();
                
                gainNode.gain.value = volumeMultiplier;
                source.connect(gainNode);
                gainNode.connect(audioContext.destination);
                
                media.audioBoostApplied = true;
                media.gainNode = gainNode;
            } catch (e) {
                console.log("Web Audio API not available:", e);
            }
        } else if (media.gainNode) {
            media.gainNode.gain.value = volumeMultiplier;
        }
    });
    
    // Store setting
    window.volumeSetting = volumePercent;
}


// Update all tabs based on priority system
function updateAllTabsVolume() {
    chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
            const settings = tabSettings[tab.id];
            if (settings) {
                let volumeToApply = settings.volume;
                
                // If there's a priority tab and this isn't it, reduce volume
                if (priorityTabId && priorityTabId !== tab.id) {
                    volumeToApply = Math.min(30, settings.volume); // Background tabs max 30%
                }
                
                applyVolumeToTab(tab.id, volumeToApply);
            }
        });
    });
}


// Clean up closed tabs
chrome.tabs.onRemoved.addListener((tabId) => {
    delete tabSettings[tabId];
    if (priorityTabId === tabId) {
        priorityTabId = null;
    }
});


// Initialize
chrome.runtime.onInstalled.addListener(() => {
    console.log("Volume Master installed");
});