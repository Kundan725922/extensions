let currentTabId = null;

// Initialize popup
document.addEventListener('DOMContentLoaded', () => {
    const volumeSlider = document.getElementById('volumeSlider');
    const volumeValue = document.getElementById('volumeValue');
    const boostIndicator = document.getElementById('boostIndicator');
    const presetButtons = document.querySelectorAll('.preset-btn');
    const refreshButton = document.getElementById('refreshTabs');
    const qualityButtons = document.querySelectorAll('.quality-btn');

    let currentQualityMode = 'maximum_quality';

    // Get current tab
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
            currentTabId = tabs[0].id;
            loadCurrentTabSettings();
            loadAllAudioTabs();
        }
    });

    // Volume slider change
    volumeSlider.addEventListener('input', (e) => {
        const volume = parseInt(e.target.value);
        updateVolumeDisplay(volume);
    });

    volumeSlider.addEventListener('change', (e) => {
        const volume = parseInt(e.target.value);
        applyVolume(volume);
    });

    // Preset buttons
    presetButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            const volume = parseInt(btn.dataset.volume);
            volumeSlider.value = volume;
            updateVolumeDisplay(volume);
            applyVolume(volume);
        });
    });

    // Refresh tabs button
    refreshButton.addEventListener('click', () => {
        loadAllAudioTabs();
    });

    // Quality mode buttons
    qualityButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            // Remove active class from all
            qualityButtons.forEach(b => b.classList.remove('active'));
            // Add to clicked
            btn.classList.add('active');
            
            const mode = btn.dataset.mode;
            currentQualityMode = mode;
            
            // Apply quality mode to current tab
            chrome.tabs.sendMessage(currentTabId, {
                action: 'set_quality_mode',
                mode: mode
            }).catch(err => console.log(err));
            
            // Save preference
            chrome.storage.local.set({ qualityMode: mode });
        });
    });

    // Load quality mode preference
    chrome.storage.local.get(['qualityMode'], (result) => {
        if (result.qualityMode) {
            currentQualityMode = result.qualityMode;
            qualityButtons.forEach(btn => {
                if (btn.dataset.mode === currentQualityMode) {
                    btn.classList.add('active');
                } else {
                    btn.classList.remove('active');
                }
            });
        }
    });

    // Update display
    function updateVolumeDisplay(volume) {
        volumeValue.textContent = volume;
        
        if (volume === 0) {
            boostIndicator.innerHTML = '🔇 Muted';
            boostIndicator.className = 'boost-indicator';
        } else if (volume < 100) {
            boostIndicator.innerHTML = `🔉 Reduced to ${volume}%`;
            boostIndicator.className = 'boost-indicator';
        } else if (volume === 100) {
            boostIndicator.innerHTML = '🔊 Normal Volume';
            boostIndicator.className = 'boost-indicator';
        } else if (volume <= 300) {
            boostIndicator.innerHTML = `📢 Boosted ${volume}% - Crystal Clear`;
            boostIndicator.className = 'boost-indicator';
        } else if (volume <= 600) {
            boostIndicator.innerHTML = `🔥 High Boost ${volume}% - Quality Preserved`;
            boostIndicator.className = 'boost-indicator high';
        } else {
            boostIndicator.innerHTML = `⚡ Ultra Boost ${volume}% - Maximum Power!`;
            boostIndicator.className = 'boost-indicator high';
        }
    }

    // Apply volume to current tab
    function applyVolume(volume) {
        if (!currentTabId) return;

        // Send to background
        chrome.runtime.sendMessage({
            action: 'update_volume',
            tabId: currentTabId,
            volume: volume
        });

        // Also directly inject to content script with quality mode
        chrome.tabs.sendMessage(currentTabId, {
            action: 'set_volume',
            volume: volume
        }).then(() => {
            // Apply quality mode as well
            chrome.tabs.sendMessage(currentTabId, {
                action: 'set_quality_mode',
                mode: currentQualityMode
            });
        }).catch(err => {
            console.log("Could not send to content script:", err);
        });

        // Save to storage
        chrome.storage.local.set({ [`tab_${currentTabId}`]: volume });
    }

    // Load current tab settings
    function loadCurrentTabSettings() {
        chrome.storage.local.get([`tab_${currentTabId}`], (result) => {
            const volume = result[`tab_${currentTabId}`] || 100;
            volumeSlider.value = volume;
            updateVolumeDisplay(volume);
        });
    }

    // Load all audio tabs
    function loadAllAudioTabs() {
        chrome.tabs.query({}, (tabs) => {
            const tabsList = document.getElementById('tabsList');
            
            // Filter tabs with audio or saved settings
            const audioTabs = tabs.filter(tab => {
                return tab.audible || tab.url.includes('youtube.com') || 
                       tab.url.includes('spotify.com') || tab.url.includes('soundcloud.com') ||
                       tab.url.includes('twitch.tv') || tab.url.includes('netflix.com');
            });

            if (audioTabs.length === 0) {
                tabsList.innerHTML = '<div class="no-tabs">No audio tabs detected</div>';
                return;
            }

            // Get stored volumes
            const storageKeys = audioTabs.map(tab => `tab_${tab.id}`);
            chrome.storage.local.get(storageKeys, (results) => {
                tabsList.innerHTML = '';
                
                audioTabs.forEach(tab => {
                    const volume = results[`tab_${tab.id}`] || 100;
                    const isPriority = false; // Will implement priority system
                    
                    const tabItem = createTabItem(tab, volume, isPriority);
                    tabsList.appendChild(tabItem);
                });
            });
        });
    }

    // Create tab item element
    function createTabItem(tab, volume, isPriority) {
        const item = document.createElement('div');
        item.className = 'tab-item' + (isPriority ? ' priority' : '');
        
        const title = tab.title.length > 40 ? tab.title.substring(0, 40) + '...' : tab.title;
        const isAudible = tab.audible ? '🔊 Playing' : '⏸️ Paused';
        
        item.innerHTML = `
            <div class="tab-info">
                <div class="tab-title">${title}</div>
                <div class="tab-status">${isAudible} • Volume: ${volume}%</div>
            </div>
            <div class="tab-controls">
                <button class="priority-btn ${isPriority ? 'active' : ''}" data-tab-id="${tab.id}">
                    ${isPriority ? '⭐ Priority' : 'Set Priority'}
                </button>
            </div>
        `;

        // Priority button click
        const priorityBtn = item.querySelector('.priority-btn');
        priorityBtn.addEventListener('click', () => {
            togglePriority(tab.id);
        });

        return item;
    }

    // Toggle priority for a tab
    function togglePriority(tabId) {
        chrome.runtime.sendMessage({
            action: 'set_priority',
            tabId: tabId
        }, () => {
            loadAllAudioTabs();
        });
    }
});


// Listen for tab updates
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.audible !== undefined) {
        // Refresh the tabs list when audio state changes
        setTimeout(() => {
            const tabsList = document.getElementById('tabsList');
            if (tabsList) {
                document.getElementById('refreshTabs').click();
            }
        }, 500);
    }
});