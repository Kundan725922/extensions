const rangeInput = document.getElementById('rangeInput');
const numInput = document.getElementById('numInput');
const currentValDisplay = document.getElementById('currentVal');

// 1. Load saved speed on startup
chrome.storage.sync.get(['lastSpeed'], (data) => {
  const savedSpeed = data.lastSpeed || 1.0;
  updateUI(savedSpeed);
});

function updateUI(val) {
  val = parseFloat(val);
  currentValDisplay.innerText = val.toFixed(1);
  numInput.value = val;
  rangeInput.value = val;
}

async function setSpeed(speed) {
  const val = parseFloat(speed);
  updateUI(val);
  
  // Save to storage
  chrome.storage.sync.set({ lastSpeed: val });

  let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: injectSpeedLogic,
    args: [val]
  });
}

// Logic injected into the website
function injectSpeedLogic(newSpeed) {
  const videos = document.querySelectorAll('video');
  
  videos.forEach(video => {
    video.playbackRate = newSpeed;

    // Create or find overlay
    let overlay = document.getElementById('speed-extension-overlay');
    if (!overlay) {
      overlay = document.createElement('div');
      overlay.id = 'speed-extension-overlay';
      overlay.style.cssText = `
        position: absolute; top: 10%; right: 10%;
        background: rgba(0,0,0,0.7); color: white;
        padding: 10px 20px; border-radius: 20px;
        font-family: sans-serif; font-size: 24px;
        z-index: 999999; pointer-events: none;
        transition: opacity 0.5s;
      `;
      video.parentElement.style.position = 'relative';
      video.parentElement.appendChild(overlay);
    }
    
    overlay.innerText = newSpeed + "x";
    overlay.style.opacity = "1";
    
    // Hide overlay after 1 second
    setTimeout(() => { overlay.style.opacity = "0"; }, 1000);
  });
}

// Listeners
document.querySelectorAll('.preset').forEach(btn => {
  btn.addEventListener('click', () => setSpeed(btn.dataset.speed));
});

rangeInput.addEventListener('input', (e) => setSpeed(e.target.value));
numInput.addEventListener('change', (e) => setSpeed(e.target.value));