// Video Controller - Content Script
let videoElement = null;
let controlPanel = null;
let bookmarks = [];
let abLoop = { enabled: false, start: null, end: null };
let floatingPlayer = null;
let settings = {
    autoplayNext: false,
    silenceSkip: false,
    loop: false,
    audioMode: false
};

// Audio boost settings
let audioContext = null;
let gainNode = null;
let sourceNode = null;
let currentBoost = 1.0;
let audioQualityMode = 'balanced';

// Initialize on page load
function init() {
    findAndAttachToVideo();
    
    // Watch for dynamically added videos
    const observer = new MutationObserver(() => {
        if (!videoElement || !document.contains(videoElement)) {
            findAndAttachToVideo();
        }
    });
    
    observer.observe(document.body, {
        childList: true,
        subtree: true
    });
}

// Find video element on page
function findAndAttachToVideo() {
    const videos = document.querySelectorAll('video');
    
    if (videos.length > 0) {
        videoElement = videos[0]; // Attach to first video
        attachControlPanel();
        setupVideoListeners();
        loadBookmarks();
    }
}

// Setup video event listeners
function setupVideoListeners() {
    if (!videoElement) return;
    
    // Initialize audio boost on first play
    videoElement.addEventListener('play', () => {
        if (!audioContext) {
            initAudioBoost();
        }
    }, { once: true });
    
    // A-B Loop check
    videoElement.addEventListener('timeupdate', () => {
        if (abLoop.enabled && abLoop.start !== null && abLoop.end !== null) {
            if (videoElement.currentTime >= abLoop.end) {
                videoElement.currentTime = abLoop.start;
            }
        }
        
        // Silence skip (basic implementation)
        if (settings.silenceSkip) {
            checkSilence();
        }
        
        updateTimeDisplay();
    });
    
    // Autoplay next video
    videoElement.addEventListener('ended', () => {
        if (settings.autoplayNext) {
            playNextVideo();
        }
    });
}

// Check for silence (simplified version)
function checkSilence() {
    // This is a placeholder - real implementation would use Web Audio API
    // to analyze audio levels
}

// Create control panel UI
function attachControlPanel() {
    if (controlPanel) controlPanel.remove();
    
    controlPanel = document.createElement('div');
    controlPanel.id = 'video-control-panel';
    controlPanel.innerHTML = `
        <div class="vc-header">
            <span>🎬 Video Controller</span>
            <button class="vc-close" id="vcClose">✕</button>
        </div>
        
        <div class="vc-section">
            <h4>⏯ Playback</h4>
            <div class="vc-buttons">
                <button id="vcPlayPause" title="Play/Pause">⏯</button>
                <button id="vcRewind" title="Rewind 10s">⏪ -10s</button>
                <button id="vcForward" title="Forward 10s">⏩ +10s</button>
                <button id="vcReset" title="Reset to start">🔄</button>
            </div>
        </div>
        
        <div class="vc-section">
            <h4>⏱ Time</h4>
            <div class="vc-time-display" id="vcTime">0:00 / 0:00</div>
            <input type="text" id="vcJumpTime" placeholder="Jump to (mm:ss)" class="vc-input">
            <button id="vcJumpBtn" class="vc-btn-small">⏭ Jump</button>
        </div>
        
        <div class="vc-section">
            <h4>⚡ Speed</h4>
            <div class="vc-buttons">
                <button class="vc-speed" data-speed="0.25">0.25x</button>
                <button class="vc-speed" data-speed="0.5">0.5x</button>
                <button class="vc-speed" data-speed="1">1x</button>
                <button class="vc-speed" data-speed="1.5">1.5x</button>
                <button class="vc-speed" data-speed="2">2x</button>
                <button class="vc-speed" data-speed="3">3x</button>
                <button class="vc-speed" data-speed="4">4x</button>
            </div>
            <input type="number" id="vcCustomSpeed" placeholder="Custom" step="0.1" min="0.1" max="16" class="vc-input">
            <button id="vcSetSpeed" class="vc-btn-small">Set</button>
        </div>
        
        <div class="vc-section">
            <h4>🔊 Volume</h4>
            <input type="range" id="vcVolume" min="0" max="100" value="100" class="vc-slider">
            <span id="vcVolumeValue">100%</span>
            <button id="vcMute" class="vc-btn-small">🔊 Mute</button>
        </div>
        
        <div class="vc-section">
            <h4>🔊 Volume Master</h4>
            <p class="vc-subtitle">Boost & Control Audio</p>
            <div class="vc-volume-display" id="vcBoostDisplay">100%</div>
            <label class="vc-label">Current Tab Volume</label>
            <div class="vc-boost-buttons">
                <button class="vc-boost-btn" data-boost="0.5">50%</button>
                <button class="vc-boost-btn vc-boost-active" data-boost="1">100%</button>
                <button class="vc-boost-btn" data-boost="2">200%</button>
                <button class="vc-boost-btn" data-boost="3">300%</button>
                <button class="vc-boost-btn" data-boost="5">500%</button>
                <button class="vc-boost-btn" data-boost="8">800%</button>
            </div>
            <button id="vcResetBoost" class="vc-btn-small">🔊 Normal Volume</button>
            
            <label class="vc-label" style="margin-top: 15px;">🎚️ Audio Quality Mode</label>
            <div class="vc-quality-options">
                <label class="vc-radio">
                    <input type="radio" name="audioQuality" value="maximum" id="qualityMax">
                    <div class="vc-radio-content">
                        <strong>Maximum Quality</strong>
                        <span>Best sound, gentle boost</span>
                    </div>
                </label>
                <label class="vc-radio">
                    <input type="radio" name="audioQuality" value="balanced" id="qualityBalanced" checked>
                    <div class="vc-radio-content">
                        <strong>Balanced</strong>
                        <span>Great quality + volume</span>
                    </div>
                </label>
                <label class="vc-radio">
                    <input type="radio" name="audioQuality" value="loudness" id="qualityLoudness">
                    <div class="vc-radio-content">
                        <strong>Maximum Loudness</strong>
                        <span>Loudest possible</span>
                    </div>
                </label>
            </div>
        </div>
        
        <div class="vc-section">
            <h4>🔄 Transform</h4>
            <div class="vc-buttons">
                <button id="vcRotate" title="Rotate 90°">🔃 Rotate</button>
                <button id="vcMirrorH" title="Mirror Horizontal">↔️ Flip H</button>
                <button id="vcMirrorV" title="Mirror Vertical">↕️ Flip V</button>
            </div>
            <label>Opacity: <span id="vcOpacityValue">100%</span></label>
            <input type="range" id="vcOpacity" min="0" max="100" value="100" class="vc-slider">
        </div>
        
        <div class="vc-section">
            <h4>🔁 A-B Loop</h4>
            <div class="vc-buttons">
                <button id="vcSetA">Set Point A</button>
                <button id="vcSetB">Set Point B</button>
                <button id="vcToggleAB" class="vc-inactive">Enable Loop</button>
                <button id="vcClearAB">Clear</button>
            </div>
            <div id="vcAbDisplay" class="vc-ab-display">A: -- | B: --</div>
        </div>
        
        <div class="vc-section">
            <h4>🔖 Bookmarks</h4>
            <button id="vcAddBookmark" class="vc-btn-small">➕ Add Bookmark</button>
            <div id="vcBookmarkList" class="vc-bookmark-list"></div>
        </div>
        
        <div class="vc-section">
            <h4>⚙️ Settings</h4>
            <label class="vc-checkbox">
                <input type="checkbox" id="vcAutoplay"> ⏭ Autoplay Next
            </label>
            <label class="vc-checkbox">
                <input type="checkbox" id="vcSilenceSkip"> 💨 Silence Skip
            </label>
            <label class="vc-checkbox">
                <input type="checkbox" id="vcLoop"> 🔁 Loop Video
            </label>
            <label class="vc-checkbox">
                <input type="checkbox" id="vcAudioMode"> 🎧 Audio Mode
            </label>
        </div>
        
        <div class="vc-section">
            <h4>🎬 Special</h4>
            <div class="vc-buttons">
                <button id="vcFloating">🖼️ Floating Player</button>
                <button id="vcFullscreen">⛶ Fullscreen</button>
                <button id="vcPrevious">⬅️ Previous</button>
                <button id="vcNext">➡️ Next</button>
            </div>
        </div>
    `;
    
    document.body.appendChild(controlPanel);
    attachEventListeners();
    updateTimeDisplay();
}

// Attach all event listeners
function attachEventListeners() {
    // Close button
    document.getElementById('vcClose').onclick = () => {
        controlPanel.style.display = 'none';
    };
    
    // Playback controls
    document.getElementById('vcPlayPause').onclick = togglePlayPause;
    document.getElementById('vcRewind').onclick = () => skipTime(-10);
    document.getElementById('vcForward').onclick = () => skipTime(10);
    document.getElementById('vcReset').onclick = () => videoElement.currentTime = 0;
    
    // Speed controls
    document.querySelectorAll('.vc-speed').forEach(btn => {
        btn.onclick = () => setSpeed(parseFloat(btn.dataset.speed));
    });
    document.getElementById('vcSetSpeed').onclick = () => {
        const speed = parseFloat(document.getElementById('vcCustomSpeed').value);
        if (speed && speed > 0) setSpeed(speed);
    };
    
    // Volume controls
    const volumeSlider = document.getElementById('vcVolume');
    volumeSlider.oninput = () => {
        const vol = volumeSlider.value / 100;
        videoElement.volume = vol;
        document.getElementById('vcVolumeValue').textContent = volumeSlider.value + '%';
    };
    document.getElementById('vcMute').onclick = toggleMute;
    
    // Volume Boost controls
    document.querySelectorAll('.vc-boost-btn').forEach(btn => {
        btn.onclick = () => {
            const boost = parseFloat(btn.dataset.boost);
            setVolumeBoost(boost);
            
            // Update active state
            document.querySelectorAll('.vc-boost-btn').forEach(b => 
                b.classList.remove('vc-boost-active'));
            btn.classList.add('vc-boost-active');
        };
    });
    
    document.getElementById('vcResetBoost').onclick = () => {
        setVolumeBoost(1.0);
        document.querySelectorAll('.vc-boost-btn').forEach(b => 
            b.classList.remove('vc-boost-active'));
        document.querySelector('[data-boost="1"]').classList.add('vc-boost-active');
    };
    
    // Audio quality mode
    document.querySelectorAll('input[name="audioQuality"]').forEach(radio => {
        radio.onchange = (e) => {
            audioQualityMode = e.target.value;
            applyAudioQuality();
        };
    });
    
    // Transform controls
    let rotation = 0;
    let mirrorH = false;
    let mirrorV = false;
    
    document.getElementById('vcRotate').onclick = () => {
        rotation = (rotation + 90) % 360;
        updateTransform(rotation, mirrorH, mirrorV);
    };
    
    document.getElementById('vcMirrorH').onclick = () => {
        mirrorH = !mirrorH;
        updateTransform(rotation, mirrorH, mirrorV);
    };
    
    document.getElementById('vcMirrorV').onclick = () => {
        mirrorV = !mirrorV;
        updateTransform(rotation, mirrorH, mirrorV);
    };
    
    const opacitySlider = document.getElementById('vcOpacity');
    opacitySlider.oninput = () => {
        videoElement.style.opacity = opacitySlider.value / 100;
        document.getElementById('vcOpacityValue').textContent = opacitySlider.value + '%';
    };
    
    // A-B Loop
    document.getElementById('vcSetA').onclick = () => {
        abLoop.start = videoElement.currentTime;
        updateAbDisplay();
    };
    document.getElementById('vcSetB').onclick = () => {
        abLoop.end = videoElement.currentTime;
        updateAbDisplay();
    };
    document.getElementById('vcToggleAB').onclick = toggleAbLoop;
    document.getElementById('vcClearAB').onclick = clearAbLoop;
    
    // Bookmarks
    document.getElementById('vcAddBookmark').onclick = addBookmark;
    
    // Jump to time
    document.getElementById('vcJumpBtn').onclick = jumpToTime;
    document.getElementById('vcJumpTime').onkeypress = (e) => {
        if (e.key === 'Enter') jumpToTime();
    };
    
    // Settings checkboxes
    document.getElementById('vcAutoplay').onchange = (e) => {
        settings.autoplayNext = e.target.checked;
    };
    document.getElementById('vcSilenceSkip').onchange = (e) => {
        settings.silenceSkip = e.target.checked;
    };
    document.getElementById('vcLoop').onchange = (e) => {
        settings.loop = e.target.checked;
        videoElement.loop = e.target.checked;
    };
    document.getElementById('vcAudioMode').onchange = (e) => {
        settings.audioMode = e.target.checked;
        toggleAudioMode(e.target.checked);
    };
    
    // Special features
    document.getElementById('vcFloating').onclick = createFloatingPlayer;
    document.getElementById('vcFullscreen').onclick = toggleFullscreen;
    document.getElementById('vcPrevious').onclick = playPreviousVideo;
    document.getElementById('vcNext').onclick = playNextVideo;
}

// Playback functions
function togglePlayPause() {
    if (videoElement.paused) {
        videoElement.play();
    } else {
        videoElement.pause();
    }
}

function skipTime(seconds) {
    videoElement.currentTime += seconds;
}

function setSpeed(speed) {
    videoElement.playbackRate = speed;
}

function toggleMute() {
    videoElement.muted = !videoElement.muted;
    const btn = document.getElementById('vcMute');
    btn.textContent = videoElement.muted ? '🔇 Unmute' : '🔊 Mute';
}

// Volume Boost System using Web Audio API
function initAudioBoost() {
    if (!videoElement || audioContext) return;
    
    try {
        // Create audio context
        audioContext = new (window.AudioContext || window.webkitAudioContext)();
        
        // Create gain node
        gainNode = audioContext.createGain();
        
        // Create source from video element
        sourceNode = audioContext.createMediaElementSource(videoElement);
        
        // Connect: source -> gain -> destination
        sourceNode.connect(gainNode);
        gainNode.connect(audioContext.destination);
        
        // Set initial gain
        gainNode.gain.value = currentBoost;
        
        console.log('Audio boost initialized');
    } catch (error) {
        console.error('Failed to initialize audio boost:', error);
    }
}

function setVolumeBoost(boost) {
    currentBoost = boost;
    
    // Initialize audio context if not already done
    if (!audioContext && videoElement) {
        initAudioBoost();
    }
    
    // Apply boost
    if (gainNode) {
        // Smooth transition to avoid clicking
        const currentTime = audioContext.currentTime;
        gainNode.gain.cancelScheduledValues(currentTime);
        gainNode.gain.setValueAtTime(gainNode.gain.value, currentTime);
        gainNode.gain.linearRampToValueAtTime(boost, currentTime + 0.1);
    }
    
    // Update display
    const boostPercent = Math.round(boost * 100);
    document.getElementById('vcBoostDisplay').textContent = `${boostPercent}%`;
    
    // Apply quality adjustments
    applyAudioQuality();
}

function applyAudioQuality() {
    if (!audioContext || !gainNode) return;
    
    // Remove any existing filters
    if (gainNode.biquadFilter) {
        gainNode.disconnect();
        gainNode.connect(audioContext.destination);
    }
    
    // Apply quality-specific processing
    switch(audioQualityMode) {
        case 'maximum':
            // Clean boost with compression
            applyCompression(2, -24, 0.003, 0.25);
            break;
            
        case 'balanced':
            // Balanced compression
            applyCompression(4, -30, 0.003, 0.25);
            break;
            
        case 'loudness':
            // Aggressive compression for maximum loudness
            applyCompression(12, -50, 0.001, 0.05);
            break;
    }
}

function applyCompression(ratio, threshold, attack, release) {
    if (!audioContext || !gainNode) return;
    
    try {
        // Create compressor
        const compressor = audioContext.createDynamicsCompressor();
        compressor.threshold.value = threshold;
        compressor.knee.value = 30;
        compressor.ratio.value = ratio;
        compressor.attack.value = attack;
        compressor.release.value = release;
        
        // Reconnect with compressor
        gainNode.disconnect();
        gainNode.connect(compressor);
        compressor.connect(audioContext.destination);
        
        console.log(`Applied ${audioQualityMode} mode: ratio=${ratio}, threshold=${threshold}`);
    } catch (error) {
        console.error('Compression error:', error);
    }
}

// Transform functions
function updateTransform(rotation, mirrorH, mirrorV) {
    const scaleX = mirrorH ? -1 : 1;
    const scaleY = mirrorV ? -1 : 1;
    videoElement.style.transform = `rotate(${rotation}deg) scaleX(${scaleX}) scaleY(${scaleY})`;
}

// Time functions
function updateTimeDisplay() {
    if (!videoElement) return;
    const current = formatTime(videoElement.currentTime);
    const duration = formatTime(videoElement.duration);
    const timeDisplay = document.getElementById('vcTime');
    if (timeDisplay) {
        timeDisplay.textContent = `${current} / ${duration}`;
    }
}

function formatTime(seconds) {
    if (isNaN(seconds)) return '0:00';
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    
    if (h > 0) {
        return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
    }
    return `${m}:${s.toString().padStart(2, '0')}`;
}

function jumpToTime() {
    const input = document.getElementById('vcJumpTime').value;
    const parts = input.split(':').map(p => parseInt(p));
    
    let seconds = 0;
    if (parts.length === 2) {
        seconds = parts[0] * 60 + parts[1];
    } else if (parts.length === 3) {
        seconds = parts[0] * 3600 + parts[1] * 60 + parts[2];
    }
    
    if (seconds >= 0 && seconds <= videoElement.duration) {
        videoElement.currentTime = seconds;
    }
}

// A-B Loop functions
function toggleAbLoop() {
    if (abLoop.start === null || abLoop.end === null) {
        alert('Please set both A and B points first!');
        return;
    }
    
    abLoop.enabled = !abLoop.enabled;
    const btn = document.getElementById('vcToggleAB');
    
    if (abLoop.enabled) {
        btn.textContent = 'Disable Loop';
        btn.classList.remove('vc-inactive');
        btn.classList.add('vc-active');
    } else {
        btn.textContent = 'Enable Loop';
        btn.classList.remove('vc-active');
        btn.classList.add('vc-inactive');
    }
}

function clearAbLoop() {
    abLoop = { enabled: false, start: null, end: null };
    const btn = document.getElementById('vcToggleAB');
    btn.textContent = 'Enable Loop';
    btn.classList.remove('vc-active');
    btn.classList.add('vc-inactive');
    updateAbDisplay();
}

function updateAbDisplay() {
    const display = document.getElementById('vcAbDisplay');
    const aTime = abLoop.start !== null ? formatTime(abLoop.start) : '--';
    const bTime = abLoop.end !== null ? formatTime(abLoop.end) : '--';
    display.textContent = `A: ${aTime} | B: ${bTime}`;
}

// Bookmark functions
function addBookmark() {
    const time = videoElement.currentTime;
    const label = prompt('Bookmark name:', `Bookmark at ${formatTime(time)}`);
    
    if (label) {
        bookmarks.push({ time, label });
        saveBookmarks();
        renderBookmarks();
    }
}

function renderBookmarks() {
    const list = document.getElementById('vcBookmarkList');
    list.innerHTML = '';
    
    bookmarks.forEach((bookmark, index) => {
        const item = document.createElement('div');
        item.className = 'vc-bookmark-item';
        item.innerHTML = `
            <span class="vc-bookmark-label" title="${bookmark.label}">
                ${bookmark.label} (${formatTime(bookmark.time)})
            </span>
            <button class="vc-bookmark-go" data-index="${index}">Go</button>
            <button class="vc-bookmark-delete" data-index="${index}">✕</button>
        `;
        list.appendChild(item);
    });
    
    // Attach bookmark event listeners
    document.querySelectorAll('.vc-bookmark-go').forEach(btn => {
        btn.onclick = () => {
            const idx = parseInt(btn.dataset.index);
            videoElement.currentTime = bookmarks[idx].time;
        };
    });
    
    document.querySelectorAll('.vc-bookmark-delete').forEach(btn => {
        btn.onclick = () => {
            const idx = parseInt(btn.dataset.index);
            bookmarks.splice(idx, 1);
            saveBookmarks();
            renderBookmarks();
        };
    });
}

function saveBookmarks() {
    const videoUrl = window.location.href;
    chrome.storage.local.set({ [`bookmarks_${videoUrl}`]: bookmarks });
}

function loadBookmarks() {
    const videoUrl = window.location.href;
    chrome.storage.local.get([`bookmarks_${videoUrl}`], (result) => {
        bookmarks = result[`bookmarks_${videoUrl}`] || [];
        renderBookmarks();
    });
}

// Audio mode
function toggleAudioMode(enabled) {
    if (enabled) {
        videoElement.style.display = 'none';
    } else {
        videoElement.style.display = '';
    }
}

// Floating player
function createFloatingPlayer() {
    if (floatingPlayer) {
        floatingPlayer.remove();
        floatingPlayer = null;
        return;
    }
    
    floatingPlayer = document.createElement('div');
    floatingPlayer.id = 'vc-floating-player';
    floatingPlayer.innerHTML = `
        <div class="vc-floating-header">
            <span>🎬 Floating</span>
            <button id="vcFloatingClose">✕</button>
        </div>
        <video id="vcFloatingVideo" controls></video>
    `;
    
    document.body.appendChild(floatingPlayer);
    
    const floatVideo = document.getElementById('vcFloatingVideo');
    floatVideo.src = videoElement.src || videoElement.currentSrc;
    floatVideo.currentTime = videoElement.currentTime;
    floatVideo.playbackRate = videoElement.playbackRate;
    
    // Sync playback
    if (!videoElement.paused) {
        floatVideo.play();
    }
    
    document.getElementById('vcFloatingClose').onclick = () => {
        floatingPlayer.remove();
        floatingPlayer = null;
    };
    
    makeDraggable(floatingPlayer);
}

function makeDraggable(element) {
    let pos = { x: 0, y: 0, startX: 0, startY: 0 };
    
    const header = element.querySelector('.vc-floating-header');
    header.onmousedown = dragStart;
    
    function dragStart(e) {
        e.preventDefault();
        pos.startX = e.clientX;
        pos.startY = e.clientY;
        document.onmouseup = dragEnd;
        document.onmousemove = drag;
    }
    
    function drag(e) {
        e.preventDefault();
        pos.x = pos.startX - e.clientX;
        pos.y = pos.startY - e.clientY;
        pos.startX = e.clientX;
        pos.startY = e.clientY;
        
        element.style.top = (element.offsetTop - pos.y) + 'px';
        element.style.left = (element.offsetLeft - pos.x) + 'px';
    }
    
    function dragEnd() {
        document.onmouseup = null;
        document.onmousemove = null;
    }
}

// Fullscreen
function toggleFullscreen() {
    if (!document.fullscreenElement) {
        videoElement.requestFullscreen().catch(err => {
            console.error('Fullscreen error:', err);
        });
    } else {
        document.exitFullscreen();
    }
}

// Navigation
function playNextVideo() {
    // Try to find and click "Next" button on the page
    const nextButtons = [
        'button[aria-label*="Next"]',
        'a[aria-label*="Next"]',
        '.ytp-next-button',
        '[title*="next" i]',
        '[title*="Next video"]'
    ];
    
    for (const selector of nextButtons) {
        const btn = document.querySelector(selector);
        if (btn) {
            btn.click();
            return;
        }
    }
    
    alert('Could not find next video button');
}

function playPreviousVideo() {
    const prevButtons = [
        'button[aria-label*="Previous"]',
        'a[aria-label*="Previous"]',
        '[title*="previous" i]',
        '[title*="Previous video"]'
    ];
    
    for (const selector of prevButtons) {
        const btn = document.querySelector(selector);
        if (btn) {
            btn.click();
            return;
        }
    }
    
    alert('Could not find previous video button');
}

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Only if control panel is visible
    if (!controlPanel || controlPanel.style.display === 'none') return;
    
    // Ignore if typing in input
    if (e.target.tagName === 'INPUT') return;
    
    switch(e.key) {
        case ' ':
            e.preventDefault();
            togglePlayPause();
            break;
        case 'ArrowLeft':
            e.preventDefault();
            skipTime(-10);
            break;
        case 'ArrowRight':
            e.preventDefault();
            skipTime(10);
            break;
        case 'f':
            toggleFullscreen();
            break;
        case 'm':
            toggleMute();
            break;
    }
});

// Listen for messages from popup/background
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'toggle_panel') {
        if (controlPanel) {
            controlPanel.style.display = controlPanel.style.display === 'none' ? 'block' : 'none';
        } else {
            findAndAttachToVideo();
        }
        sendResponse({ success: true });
    }
    return true;
});

// Initialize
setTimeout(init, 1000);