document.addEventListener('DOMContentLoaded', () => {
    // Tab switching
    const tabs = document.querySelectorAll('.tab');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const targetTab = tab.dataset.tab;
            
            // Update active tab
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            
            // Update active content
            tabContents.forEach(content => {
                content.classList.remove('active');
                if (content.id === `${targetTab}-tab`) {
                    content.classList.add('active');
                }
            });
            
            // Load audio tabs if switching to audio tab
            if (targetTab === 'audio') {
                loadAudioTabs();
            }
        });
    });
    
    // Controls tab buttons
    const togglePanelBtn = document.getElementById('togglePanel');
    const playPauseBtn = document.getElementById('playPause');
    const rewindBtn = document.getElementById('rewind');
    const forwardBtn = document.getElementById('forward');
    const fullscreenBtn = document.getElementById('fullscreen');
    const refreshBtn = document.getElementById('refreshAudioTabs');

    // Toggle control panel
    togglePanelBtn.addEventListener('click', () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            chrome.tabs.sendMessage(tabs[0].id, { action: 'toggle_panel' });
        });
    });

    // Play/Pause
    playPauseBtn.addEventListener('click', () => {
        executeInPage(`
            const video = document.querySelector('video');
            if (video) {
                if (video.paused) video.play();
                else video.pause();
            }
        `);
    });

    // Rewind
    rewindBtn.addEventListener('click', () => {
        executeInPage(`
            const video = document.querySelector('video');
            if (video) video.currentTime -= 10;
        `);
    });

    // Forward
    forwardBtn.addEventListener('click', () => {
        executeInPage(`
            const video = document.querySelector('video');
            if (video) video.currentTime += 10;
        `);
    });

    // Fullscreen
    fullscreenBtn.addEventListener('click', () => {
        executeInPage(`
            const video = document.querySelector('video');
            if (video) {
                if (!document.fullscreenElement) {
                    video.requestFullscreen();
                } else {
                    document.exitFullscreen();
                }
            }
        `);
    });
    
    // Refresh audio tabs
    refreshBtn.addEventListener('click', () => {
        loadAudioTabs();
    });

    // Helper function to execute code in page context
    function executeInPage(code) {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            chrome.scripting.executeScript({
                target: { tabId: tabs[0].id },
                func: new Function(code)
            });
        });
    }
    
    // Load audio tabs
    async function loadAudioTabs() {
        const listContainer = document.getElementById('audioTabsList');
        listContainer.innerHTML = '<div style="text-align: center; padding: 20px;">Loading...</div>';
        
        try {
            const tabs = await chrome.tabs.query({});
            const audioTabs = [];
            
            for (const tab of tabs) {
                try {
                    // Check if tab has audio/video
                    const result = await chrome.scripting.executeScript({
                        target: { tabId: tab.id },
                        func: () => {
                            const videos = document.querySelectorAll('video');
                            const audios = document.querySelectorAll('audio');
                            const hasMedia = videos.length > 0 || audios.length > 0;
                            
                            if (hasMedia && videos.length > 0) {
                                const video = videos[0];
                                return {
                                    hasMedia: true,
                                    isPlaying: !video.paused,
                                    currentTime: video.currentTime,
                                    duration: video.duration,
                                    volume: Math.round(video.volume * 100),
                                    muted: video.muted
                                };
                            } else if (hasMedia && audios.length > 0) {
                                const audio = audios[0];
                                return {
                                    hasMedia: true,
                                    isPlaying: !audio.paused,
                                    currentTime: audio.currentTime,
                                    duration: audio.duration,
                                    volume: Math.round(audio.volume * 100),
                                    muted: audio.muted
                                };
                            }
                            return { hasMedia: false };
                        }
                    });
                    
                    if (result && result[0] && result[0].result && result[0].result.hasMedia) {
                        audioTabs.push({
                            tab: tab,
                            media: result[0].result
                        });
                    }
                } catch (err) {
                    // Skip tabs where we can't inject scripts
                    continue;
                }
            }
            
            renderAudioTabs(audioTabs);
        } catch (error) {
            console.error('Error loading audio tabs:', error);
            listContainer.innerHTML = '<div class="empty-state"><div class="empty-state-icon">❌</div><p>Error loading tabs</p></div>';
        }
    }
    
    function renderAudioTabs(audioTabs) {
        const listContainer = document.getElementById('audioTabsList');
        
        if (audioTabs.length === 0) {
            listContainer.innerHTML = `
                <div class="empty-state">
                    <div class="empty-state-icon">🔊</div>
                    <p>No audio tabs detected</p>
                    <p style="font-size: 11px; margin-top: 8px;">Open tabs with video/audio and refresh</p>
                </div>
            `;
            return;
        }
        
        listContainer.innerHTML = '';
        
        audioTabs.forEach(item => {
            const { tab, media } = item;
            const tabItem = document.createElement('div');
            tabItem.className = 'audio-tab-item';
            
            const icon = media.isPlaying ? '▶️' : '⏸️';
            const status = media.muted ? '🔇 Muted' : `🔊 ${media.volume}%`;
            const timeStr = `${formatTime(media.currentTime)} / ${formatTime(media.duration)}`;
            
            tabItem.innerHTML = `
                <div class="audio-tab-icon">${icon}</div>
                <div class="audio-tab-info">
                    <div class="audio-tab-title" title="${tab.title}">${tab.title}</div>
                    <div class="audio-tab-status">${status} • ${timeStr}</div>
                </div>
                <div class="audio-tab-controls">
                    <button class="control-tab-btn" data-tab-id="${tab.id}" data-action="switch">
                        Switch
                    </button>
                    <button class="control-tab-btn" data-tab-id="${tab.id}" data-action="boost">
                        Boost
                    </button>
                </div>
            `;
            
            listContainer.appendChild(tabItem);
        });
        
        // Attach event listeners
        document.querySelectorAll('.control-tab-btn').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                const tabId = parseInt(btn.dataset.tabId);
                const action = btn.dataset.action;
                
                if (action === 'switch') {
                    // Switch to tab
                    await chrome.tabs.update(tabId, { active: true });
                    window.close();
                } else if (action === 'boost') {
                    // Open volume boost in that tab
                    await chrome.tabs.update(tabId, { active: true });
                    setTimeout(() => {
                        chrome.tabs.sendMessage(tabId, { action: 'toggle_panel' });
                    }, 500);
                    window.close();
                }
            });
        });
    }
    
    function formatTime(seconds) {
        if (isNaN(seconds) || seconds === Infinity) return '--:--';
        const m = Math.floor(seconds / 60);
        const s = Math.floor(seconds % 60);
        return `${m}:${s.toString().padStart(2, '0')}`;
    }
    
    // Auto-load audio tabs on popup open if on audio tab
    const activeTab = document.querySelector('.tab.active');
    if (activeTab && activeTab.dataset.tab === 'audio') {
        loadAudioTabs();
    }
});