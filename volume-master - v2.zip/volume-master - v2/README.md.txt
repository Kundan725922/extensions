//README.md 
# 🎬 Advanced Video Controller Extension

A powerful Chrome extension for complete video/audio control with advanced features including volume boosting up to 800%, A-B loop, bookmarks, and multi-tab audio management.

## ✨ Features Overview

### 🔊 Volume Master (NEW!)
- **Volume Boost**: Amplify audio from 50% to 800% using Web Audio API
- **Tab-Specific Control**: Manage volume independently for each tab
- **Audio Quality Modes**:
  - 🎵 **Maximum Quality**: Best sound with gentle boost
  - ⚖️ **Balanced**: Great quality with good volume
  - 📢 **Maximum Loudness**: Loudest possible output
- **Smart Compression**: Dynamic audio processing for clean boost without distortion

### 🎵 Audio Tabs Manager
- View all tabs with active audio/video
- See playback status (playing/paused)
- Check current time and duration
- Monitor volume levels per tab
- Quick switch to any audio tab
- One-click access to boost controls

### ⏯ Playback Controls
- Play/Pause toggle
- ⏪ Rewind 10 seconds
- ⏩ Forward 10 seconds
- 🔄 Reset to start
- Real-time progress display
- ⏭ Jump to specific timestamp (mm:ss format)

### ⚡ Speed Controls
- Quick presets: 0.25x, 0.5x, 1x, 1.5x, 2x, 3x, 4x
- Custom speed input (0.1x - 16x)
- Smooth speed transitions

### 🔊 Standard Volume Controls
- Volume slider (0-100%)
- 🔇 Mute/Unmute
- Independent from boost controls

### 🔄 Video Transform
- 🔃 Rotate 90° increments
- ↔️ Mirror Horizontal
- ↕️ Mirror Vertical
- Opacity control (0-100%)
- Real-time transformations

### 🔁 A-B Loop
- Set Point A (loop start)
- Set Point B (loop end)
- Enable/Disable seamless looping
- Visual A-B time markers
- Perfect for studying or practice

### 🔖 Bookmarks System
- Add unlimited bookmarks with custom names
- Instant jump to bookmarked positions
- Delete unwanted bookmarks
- Persistent storage per video URL
- Great for long videos or lectures

### ⚙️ Advanced Settings
- ⏭ **Autoplay Next**: Automatically play next video when current ends
- 💨 **Silence Skip**: Auto-skip silent parts (experimental)
- 🔁 **Loop Video**: Repeat current video infinitely
- 🎧 **Audio Mode**: Hide video, play audio only

### 🎬 Special Features
- 🖼️ **Floating Player**: Draggable mini player overlay
- ⛶ **Fullscreen**: Toggle fullscreen mode
- ⬅️ **Play Previous**: Navigate to previous video
- ➡️ **Play Next**: Navigate to next video

### ⌨️ Keyboard Shortcuts
- `Space` - Play/Pause
- `←` - Rewind 10 seconds
- `→` - Forward 10 seconds
- `F` - Toggle Fullscreen
- `M` - Mute/Unmute

## 📦 Installation

1. **Download the extension files**:
   - manifest.json
   - content_controller.js
   - controller_styles.css
   - popup_audio_tabs.html
   - popup_enhanced.js
   - background.js
   - icon.png (create or download any video-related icon)

2. **Load the extension**:
   - Open Chrome
   - Go to `chrome://extensions/`
   - Enable "Developer mode" (top right)
   - Click "Load unpacked"
   - Select your extension folder
   - Done!

## 🚀 How to Use

### Basic Usage
1. Visit any webpage with video/audio (YouTube, Vimeo, Netflix, etc.)
2. Click the extension icon in Chrome toolbar
3. Choose from quick controls or click "Toggle Control Panel"

### Volume Boost Usage
1. Open the control panel on any video
2. Scroll to "🔊 Volume Master" section
3. Click desired boost level (50% to 800%)
4. Select audio quality mode:
   - **Maximum Quality**: For music or high-quality audio
   - **Balanced**: For general use
   - **Maximum Loudness**: For quiet videos
5. Use "🔊 Normal Volume" to reset

### Audio Tabs Management
1. Click extension icon
2. Switch to "🔊 Audio Tabs" tab
3. Click "🔄 Refresh Audio Tabs" to scan all tabs
4. See all tabs with active media
5. Click "Switch" to go to that tab
6. Click "Boost" to open boost controls for that tab

### Bookmarking
1. Play video to desired position
2. Scroll to "🔖 Bookmarks" section
3. Click "➕ Add Bookmark"
4. Enter a name for the bookmark
5. Click "Go" on any bookmark to jump to that time

### A-B Loop Setup
1. Play video to start position
2. Click "Set Point A"
3. Play to end position
4. Click "Set Point B"
5. Click "Enable Loop"
6. Video will now loop between A and B

### Floating Player
1. Click "🖼️ Floating Player"
2. Drag the floating window anywhere
3. Continue browsing while video plays
4. Click X to close floating player

## 🌐 Compatible Websites

Works on virtually all websites with HTML5 video/audio:
- ✅ YouTube
- ✅ Vimeo
- ✅ Netflix
- ✅ Prime Video
- ✅ Disney+
- ✅ Twitch
- ✅ Dailymotion
- ✅ Twitter/X videos
- ✅ Facebook videos
- ✅ Local video files
- ✅ Educational platforms (Coursera, Udemy, etc.)
- ✅ And many more!

## 🎨 Features Comparison

| Feature | Basic Video Controls | This Extension |
|---------|---------------------|----------------|
| Play/Pause | ✅ | ✅ |
| Volume Control | ✅ | ✅ |
| Speed Control | Limited | 0.25x - 16x |
| Volume Boost | ❌ | 50% - 800% |
| Audio Quality Modes | ❌ | ✅ |
| Multi-Tab Management | ❌ | ✅ |
| Bookmarks | ❌ | ✅ |
| A-B Loop | ❌ | ✅ |
| Video Transform | ❌ | ✅ |
| Floating Player | ❌ | ✅ |
| Keyboard Shortcuts | Basic | Advanced |

## 🔧 Technical Details

### Volume Boost Technology
- Uses **Web Audio API** for professional-grade audio processing
- **Dynamic Range Compression** prevents distortion
- **Gain Node** for clean volume amplification
- Three compression profiles optimized for different use cases:
  - **Maximum Quality**: Low compression ratio (2:1), gentle processing
  - **Balanced**: Medium compression (4:1), optimal for most content
  - **Maximum Loudness**: High compression (12:1), aggressive boost

### Storage
- Bookmarks stored in `chrome.storage.local` per video URL
- Settings synchronized across sessions
- No data sent to external servers
- Privacy-focused design

### Performance
- Minimal CPU usage
- Efficient audio processing
- Non-blocking UI updates
- Smooth 60fps animations

## 🐛 Troubleshooting

**Q: Volume boost not working?**
- Ensure video is playing (audio context requires user interaction)
- Try refreshing the page
- Check browser console for errors

**Q: Control panel not appearing?**
- Make sure a video element exists on the page
- Try clicking "Toggle Control Panel" again
- Reload the extension

**Q: Audio Tabs not showing any tabs?**
- Click "Refresh Audio Tabs" button
- Ensure tabs have actively loaded videos
- Some protected content may not be accessible

**Q: Bookmarks not saving?**
- Check browser storage permissions
- Try clearing extension storage and re-adding bookmarks
- Ensure the video URL remains consistent

**Q: Keyboard shortcuts not working?**
- Control panel must be visible
- Make sure you're not typing in an input field
- Check for conflicts with website shortcuts

## 📝 Changelog

### Version 2.0 (Current)
- ✨ Added Volume Master with 800% boost capability
- ✨ Added Audio Quality Modes (Maximum/Balanced/Loudness)
- ✨ Added Audio Tabs Manager for multi-tab control
- ✨ Implemented Web Audio API with dynamic compression
- 🎨 Enhanced UI with gradient designs
- 🎨 Added tabbed popup interface
- ⚡ Improved performance and stability

### Version 1.0
- Initial release with basic video controls
- A-B Loop functionality
- Bookmarks system
- Video transformations
- Floating player

## 🤝 Contributing

Feel free to submit issues, fork the repository, and create pull requests for any improvements.

## 📄 License

MIT License - Free to use and modify

## 🌟 Support

If you find this extension helpful, consider:
- ⭐ Starring the repository
- 🐛 Reporting bugs
- 💡 Suggesting new features
- 📢 Sharing with friends

---

**Made with ❤️ for better video control**

*Enjoy your enhanced viewing experience!* 🎬🔊