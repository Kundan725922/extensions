// Background service worker for Video Controller v4

// Install listener
chrome.runtime.onInstalled.addListener(() => {
    console.log('Video Controller v4 extension installed');
    
    // Create context menus
    chrome.contextMenus.create({
        id: "show_video_controls",
        title: "🎬 Show Video Controls",
        contexts: ["video"]
    });
    
    chrome.contextMenus.create({
        id: "speed_controls",
        title: "⚡ Playback Speed",
        contexts: ["video"]
    });
    
    chrome.contextMenus.create({
        id: "speed_0_5",
        title: "0.5x",
        parentId: "speed_controls",
        contexts: ["video"]
    });
    
    chrome.contextMenus.create({
        id: "speed_1",
        title: "1x (Normal)",
        parentId: "speed_controls",
        contexts: ["video"]
    });
    
    chrome.contextMenus.create({
        id: "speed_1_5",
        title: "1.5x",
        parentId: "speed_controls",
        contexts: ["video"]
    });
    
    chrome.contextMenus.create({
        id: "speed_2",
        title: "2x",
        parentId: "speed_controls",
        contexts: ["video"]
    });
    
    chrome.contextMenus.create({
        id: "bookmark_current",
        title: "🔖 Bookmark Current Time",
        contexts: ["video"]
    });
    
    chrome.contextMenus.create({
        id: "set_ab_loop",
        title: "🔁 Set A-B Loop",
        contexts: ["video"]
    });
});

// Context menu click handler
chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (!tab) return;
    
    switch(info.menuItemId) {
        case "show_video_controls":
            chrome.tabs.sendMessage(tab.id, { action: 'toggle_panel' }).catch(err => {
                console.log('Could not send message:', err);
            });
            break;
            
        case "speed_0_5":
            setVideoSpeed(tab.id, 0.5);
            break;
            
        case "speed_1":
            setVideoSpeed(tab.id, 1);
            break;
            
        case "speed_1_5":
            setVideoSpeed(tab.id, 1.5);
            break;
            
        case "speed_2":
            setVideoSpeed(tab.id, 2);
            break;
            
        case "bookmark_current":
            chrome.scripting.executeScript({
                target: { tabId: tab.id },
                func: () => {
                    const video = document.querySelector('video');
                    if (video) {
                        const event = new CustomEvent('vc-add-bookmark');
                        document.dispatchEvent(event);
                    }
                }
            }).catch(err => console.log('Script execution error:', err));
            break;
            
        case "set_ab_loop":
            chrome.tabs.sendMessage(tab.id, { action: 'show_ab_loop_dialog' }).catch(err => {
                console.log('Could not send message:', err);
            });
            break;
    }
});

// Helper function to set video speed
function setVideoSpeed(tabId, speed) {
    chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: (s) => {
            const video = document.querySelector('video');
            if (video) {
                video.playbackRate = s;
                
                // Show notification
                const notification = document.createElement('div');
                notification.style.cssText = `
                    position: fixed;
                    top: 20px;
                    left: 50%;
                    transform: translateX(-50%);
                    background: rgba(0, 0, 0, 0.9);
                    color: white;
                    padding: 15px 30px;
                    border-radius: 8px;
                    font-family: Arial, sans-serif;
                    font-size: 14px;
                    z-index: 999999;
                    pointer-events: none;
                `;
                notification.textContent = `⚡ Speed: ${s}x`;
                document.body.appendChild(notification);
                
                setTimeout(() => notification.remove(), 2000);
            }
        },
        args: [speed]
    }).catch(err => console.log('Speed change error:', err));
}

// Message listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'notification') {
        // Show browser notification if API is available
        if (chrome.notifications) {
            chrome.notifications.create({
                type: 'basic',
                iconUrl: 'icon.png',
                title: 'Video Controller',
                message: request.message
            });
        }
    }
    
    sendResponse({ success: true });
    return true;
});

// Commands listener (optional keyboard shortcuts)
if (chrome.commands && chrome.commands.onCommand) {
    chrome.commands.onCommand.addListener((command) => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
                switch(command) {
                    case "toggle-panel":
                        chrome.tabs.sendMessage(tabs[0].id, { action: 'toggle_panel' }).catch(err => {
                            console.log('Could not send message:', err);
                        });
                        break;
                    case "play-pause":
                        executeVideoCommand(tabs[0].id, 'playPause');
                        break;
                    case "rewind":
                        executeVideoCommand(tabs[0].id, 'rewind');
                        break;
                    case "forward":
                        executeVideoCommand(tabs[0].id, 'forward');
                        break;
                }
            }
        });
    });
}

function executeVideoCommand(tabId, command) {
    const commands = {
        playPause: () => {
            const v = document.querySelector('video');
            if (v) v.paused ? v.play() : v.pause();
        },
        rewind: () => {
            const v = document.querySelector('video');
            if (v) v.currentTime -= 10;
        },
        forward: () => {
            const v = document.querySelector('video');
            if (v) v.currentTime += 10;
        }
    };
    
    if (commands[command]) {
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: commands[command]
        }).catch(err => console.log('Command execution error:', err));
    }
}