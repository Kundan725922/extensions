// Message listener for all communication
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    
    // Handle content detection messages
    if (request.action === "content_detected") {
        if (!sender.tab || !sender.tab.id) {
            return true; 
        }
        
        const tabId = sender.tab.id;
        chrome.action.enable(tabId);
        chrome.action.setTitle({ 
            tabId: tabId, 
            title: "Full Capture: Ready" 
        });
        return true;
    }
    
    // Handle capture commands from popup
    if (request.action === "capture_visible" || request.action === "capture_full_page" || request.action === "capture_selective") {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
                // Check if it's a PDF
                if (tabs[0].url && tabs[0].url.toLowerCase().endsWith('.pdf')) {
                    if (request.action === "capture_full_page") {
                        captureFullPDF(tabs[0].id);
                    } else {
                        performCapture(tabs[0].id, request.action);
                    }
                } else {
                    performCapture(tabs[0].id, request.action);
                }
            }
        });
        return true;
    }

    // Handle selective capture with cropping
    if (request.action === 'capture_and_crop') {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
                captureAndCrop(tabs[0].id, request.rect);
            }
        });
        return true;
    }

    // Handle PDF viewport capture request
    if (request.action === 'capture_current_viewport') {
        chrome.tabs.captureVisibleTab(null, { format: "png" }, (screenshotUrl) => {
            if (chrome.runtime.lastError) {
                console.error("PDF viewport capture failed:", chrome.runtime.lastError);
                sendResponse({ dataUrl: null });
            } else {
                sendResponse({ dataUrl: screenshotUrl });
            }
        });
        return true; // Keep channel open for async response
    }

    // Handle final download
    if (request.action === 'final_download') {
        console.log("Downloading screenshot...");
        downloadScreenshot(request.dataUrl, request.filename);
        sendResponse({ success: true });
        return true;
    }

    return true; 
});


// Perform capture with permission check
function performCapture(tabId, actionType) {
    if (actionType === 'capture_visible') {
        captureVisibleArea(tabId);
    } else if (actionType === 'capture_full_page') {
        captureFullScrollablePage(tabId);
    } else if (actionType === 'capture_selective') {
        startSelectiveMode(tabId);
    }
}


// Context menu setup
chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
        id: "capture_visible_rightclick",
        title: "Capture Visible Screen",
        contexts: ["action"]
    });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "capture_visible_rightclick" && tab) {
        performCapture(tab.id, 'capture_visible');
    }
});


// Download screenshot
function downloadScreenshot(dataUrl, filename) {
    chrome.downloads.download({
        url: dataUrl,
        filename: filename,
        saveAs: false 
    }, (downloadId) => {
        if (chrome.runtime.lastError) {
            console.error("Download error:", chrome.runtime.lastError);
        } else {
            console.log("Download started successfully:", downloadId);
        }
    });
}


// Capture visible area only
function captureVisibleArea(tabId) {
    chrome.tabs.captureVisibleTab(null, { format: "png" }, (screenshotUrl) => {
        if (chrome.runtime.lastError) {
            console.error("Capture failed:", chrome.runtime.lastError.message);
            alert("Capture Failed: " + chrome.runtime.lastError.message);
            return;
        }
        
        if (screenshotUrl) {
            downloadScreenshot(
                screenshotUrl, 
                `screenshot_visible_${Date.now()}.png`
            );
        }
    });
}


// Capture full PDF document
function captureFullPDF(tabId) {
    console.log("Starting PDF capture...");
    
    // Inject PDF capture script
    chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ['pdf_capture.js']
    }).then(() => {
        console.log("PDF capture script injected");
        
        // Send message to start PDF capture
        chrome.tabs.sendMessage(tabId, { 
            action: 'capture_pdf_full'
        }, (response) => {
            if (chrome.runtime.lastError) {
                console.error("PDF capture message error:", chrome.runtime.lastError);
                // Fallback to regular scrollable capture
                captureFullScrollablePage(tabId);
            }
        });
    }).catch((error) => {
        console.error("Failed to inject PDF script:", error);
        // Fallback to regular scrollable capture
        captureFullScrollablePage(tabId);
    });
}


// Capture full scrollable page
function captureFullScrollablePage(tabId) {
    console.log("Starting full page capture...");
    
    // First, inject the content script if not already present
    chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ['content_detector.js']
    }).catch(() => {
        console.log("Content script already present");
    });

    // Small delay to ensure content script is ready
    setTimeout(() => {
        // Get page dimensions
        chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: () => {
                window.scrollTo(0, 0);
                return {
                    fullHeight: Math.max(
                        document.body.scrollHeight,
                        document.documentElement.scrollHeight,
                        document.body.offsetHeight,
                        document.documentElement.offsetHeight
                    ),
                    viewportWidth: window.innerWidth,
                    viewportHeight: window.innerHeight
                };
            }
        }).then((results) => {
            if (!results || !results[0] || !results[0].result) {
                alert("Error: Cannot capture this page (restricted or invalid).");
                return;
            }
            
            const { fullHeight, viewportWidth, viewportHeight } = results[0].result;
            console.log("Page dimensions:", fullHeight, viewportWidth, viewportHeight);
            
            // Start the capture loop
            captureLoop(tabId, fullHeight, viewportWidth, viewportHeight, 0, []);
            
        }).catch((error) => {
            console.error("Script injection failed:", error);
            alert("Cannot capture this page. It may be restricted (e.g., Chrome Web Store).");
        });
    }, 200);
}


// Recursive capture loop
function captureLoop(tabId, fullHeight, viewportWidth, viewportHeight, currentScroll, images) {
    console.log(`Capturing at scroll position: ${currentScroll}/${fullHeight}`);
    
    // Base case: finished scrolling
    if (currentScroll >= fullHeight) {
        console.log("Capture complete! Total images:", images.length);
        
        // Send all images to content script for stitching
        chrome.tabs.sendMessage(tabId, { 
            action: 'stitch_and_download', 
            images: images, 
            fullHeight: fullHeight,
            viewportWidth: viewportWidth,
            viewportHeight: viewportHeight
        }, (response) => {
            if (chrome.runtime.lastError) {
                console.error("Message send error:", chrome.runtime.lastError);
                alert("Error: Could not communicate with page. Try refreshing the page.");
            } else {
                console.log("Stitch command sent successfully");
            }
        });
        return;
    }

    // Scroll to position
    chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: (scrollPos) => {
            window.scrollTo(0, scrollPos);
        },
        args: [currentScroll]
    }).then(() => {
        // Wait for scroll and render
        return new Promise(resolve => setTimeout(resolve, 400));
    }).then(() => {
        // Capture the visible tab
        chrome.tabs.captureVisibleTab(null, { format: "png" }, (screenshotUrl) => {
            if (chrome.runtime.lastError) {
                console.error("Capture error:", chrome.runtime.lastError);
                return;
            }
            
            if (screenshotUrl) {
                images.push({ 
                    url: screenshotUrl, 
                    scroll: currentScroll 
                });
                console.log(`Captured image ${images.length}`);
                
                // Continue to next section
                const nextScroll = currentScroll + viewportHeight;
                captureLoop(tabId, fullHeight, viewportWidth, viewportHeight, nextScroll, images);
            }
        });
    }).catch((error) => {
        console.error("Scroll error:", error);
    });
}


// Start selective capture mode
function startSelectiveMode(tabId) {
    chrome.tabs.sendMessage(tabId, { 
        action: 'start_selective_capture'
    }, (response) => {
        if (chrome.runtime.lastError) {
            console.error("Could not start selective mode:", chrome.runtime.lastError);
            alert("Error: Could not start selection mode. Try refreshing the page.");
        }
    });
}


// Capture and crop selected area
function captureAndCrop(tabId, rect) {
    console.log("Capturing selected area:", rect);
    
    chrome.tabs.captureVisibleTab(null, { format: "png" }, (screenshotUrl) => {
        if (chrome.runtime.lastError) {
            console.error("Capture failed:", chrome.runtime.lastError);
            return;
        }

        // Send the screenshot and rect to content script for cropping
        chrome.tabs.sendMessage(tabId, {
            action: 'crop_image',
            imageUrl: screenshotUrl,
            rect: rect
        }, (response) => {
            if (chrome.runtime.lastError) {
                console.error("Crop message error:", chrome.runtime.lastError);
            }
        });
    });
}