document.addEventListener('DOMContentLoaded', () => {
    const visibleBtn = document.getElementById('visibleBtn');
    const fullBtn = document.getElementById('fullBtn');
    const selectBtn = document.getElementById('selectBtn');

    // Send capture command to background script
    function sendCaptureCommand(action) {
        chrome.runtime.sendMessage({ action: action }, (response) => {
            if (chrome.runtime.lastError) {
                console.error("Message error:", chrome.runtime.lastError);
            }
            // Close popup after sending command
            setTimeout(() => window.close(), 100);
        });
    }

    // Button click handlers
    visibleBtn.addEventListener('click', () => {
        sendCaptureCommand('capture_visible');
    });

    fullBtn.addEventListener('click', () => {
        sendCaptureCommand('capture_full_page');
    });

    selectBtn.addEventListener('click', () => {
        sendCaptureCommand('capture_selective');
    });
});