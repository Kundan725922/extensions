// PDF Capture Script - Handles capturing PDF documents

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'capture_pdf_full') {
        capturePDFDocument();
        sendResponse({ success: true });
        return true;
    }
});

async function capturePDFDocument() {
    console.log("Starting PDF document capture...");
    
    // Check if this is Chrome's PDF viewer
    const isPDFViewer = document.querySelector('embed[type="application/pdf"]') || 
                        window.location.href.includes('chrome-extension://') ||
                        document.contentType === 'application/pdf';
    
    if (!isPDFViewer) {
        console.log("Not a PDF viewer, falling back to regular capture");
        return;
    }

    try {
        // For Chrome's built-in PDF viewer, we need to scroll through it
        const pdfEmbed = document.querySelector('embed[type="application/pdf"]');
        
        if (pdfEmbed) {
            // PDF is in an embed element
            await captureEmbeddedPDF(pdfEmbed);
        } else {
            // Try to detect PDF.js or other viewers
            await capturePDFViewerScroll();
        }
        
    } catch (error) {
        console.error("PDF capture error:", error);
        alert("PDF capture failed. The extension will try standard scrolling capture.");
    }
}

async function capturePDFViewerScroll() {
    console.log("Capturing PDF via scroll method...");
    
    // Scroll to top first
    window.scrollTo(0, 0);
    await sleep(300);
    
    // Get dimensions
    const fullHeight = Math.max(
        document.body.scrollHeight,
        document.documentElement.scrollHeight,
        document.body.offsetHeight,
        document.documentElement.offsetHeight
    );
    
    const viewportHeight = window.innerHeight;
    const viewportWidth = window.innerWidth;
    
    console.log(`PDF dimensions: ${viewportWidth}x${fullHeight}, viewport: ${viewportHeight}`);
    
    // Notify user
    showNotification("Capturing PDF... This may take a moment.");
    
    const images = [];
    let currentScroll = 0;
    
    // Capture loop
    while (currentScroll < fullHeight) {
        console.log(`Capturing at position: ${currentScroll}/${fullHeight}`);
        
        // Scroll to position
        window.scrollTo(0, currentScroll);
        await sleep(600); // Longer delay for PDF rendering
        
        // Request capture from background
        const screenshot = await captureCurrentView();
        
        if (screenshot) {
            images.push({
                url: screenshot,
                scroll: currentScroll
            });
        }
        
        currentScroll += viewportHeight;
    }
    
    console.log(`PDF capture complete! Total images: ${images.length}`);
    
    // Stitch images
    if (images.length > 0) {
        stitchImagesAndDownload(images, fullHeight, viewportWidth, viewportHeight);
    } else {
        alert("Failed to capture PDF pages.");
    }
}

async function captureEmbeddedPDF(embedElement) {
    console.log("Capturing embedded PDF...");
    
    showNotification("Capturing embedded PDF...");
    
    // For embedded PDFs, we'll use a scrolling approach on the container
    const container = embedElement.parentElement || document.body;
    
    const fullHeight = container.scrollHeight || embedElement.offsetHeight;
    const viewportHeight = window.innerHeight;
    const viewportWidth = window.innerWidth;
    
    const images = [];
    let currentScroll = 0;
    
    while (currentScroll < fullHeight) {
        window.scrollTo(0, currentScroll);
        await sleep(700);
        
        const screenshot = await captureCurrentView();
        if (screenshot) {
            images.push({
                url: screenshot,
                scroll: currentScroll
            });
        }
        
        currentScroll += viewportHeight;
    }
    
    if (images.length > 0) {
        stitchImagesAndDownload(images, fullHeight, viewportWidth, viewportHeight);
    }
}

// Helper to capture current viewport
function captureCurrentView() {
    return new Promise((resolve) => {
        chrome.runtime.sendMessage({ 
            action: 'capture_current_viewport'
        }, (response) => {
            if (chrome.runtime.lastError) {
                console.error("Capture error:", chrome.runtime.lastError);
                resolve(null);
            } else {
                resolve(response ? response.dataUrl : null);
            }
        });
    });
}

// Stitch PDF images together
function stitchImagesAndDownload(images, fullHeight, viewportWidth, viewportHeight) {
    if (!images || images.length === 0) {
        alert("Error: No PDF images to stitch!");
        return;
    }

    console.log("Stitching PDF images...", images.length);
    
    showNotification("Processing PDF images...");

    const canvas = document.createElement('canvas');
    canvas.width = viewportWidth;
    canvas.height = fullHeight;
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, viewportWidth, fullHeight);

    let imagesLoaded = 0;
    const totalImages = images.length;

    images.forEach((imgData, index) => {
        const img = new Image();
        
        img.onload = () => {
            console.log(`Drawing PDF page ${index + 1}/${totalImages}`);
            
            ctx.drawImage(img, 0, imgData.scroll, viewportWidth, viewportHeight);
            imagesLoaded++;

            if (imagesLoaded === totalImages) {
                console.log("All PDF pages processed!");
                
                canvas.toBlob((blob) => {
                    if (!blob) {
                        alert("Error: Failed to create PDF image");
                        return;
                    }

                    const reader = new FileReader();
                    reader.onloadend = () => {
                        const dataUrl = reader.result;
                        
                        chrome.runtime.sendMessage({ 
                            action: 'final_download', 
                            dataUrl: dataUrl, 
                            filename: `pdf_capture_${Date.now()}.png`
                        }, (response) => {
                            if (chrome.runtime.lastError) {
                                alert("Error: Could not download PDF capture");
                            } else {
                                window.scrollTo(0, 0);
                                showNotification("PDF captured successfully!", true);
                            }
                        });
                    };
                    
                    reader.readAsDataURL(blob);
                    
                }, 'image/png', 1.0);
            }
        };

        img.onerror = () => {
            console.error(`Failed to load PDF page ${index}`);
        };

        img.src = imgData.url;
    });
}

// Show notification to user
function showNotification(message, autoHide = false) {
    let notification = document.getElementById('pdf-capture-notification');
    
    if (!notification) {
        notification = document.createElement('div');
        notification.id = 'pdf-capture-notification';
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(0, 0, 0, 0.9);
            color: white;
            padding: 15px 25px;
            border-radius: 8px;
            font-family: Arial, sans-serif;
            font-size: 14px;
            z-index: 999999;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        `;
        document.body.appendChild(notification);
    }
    
    notification.textContent = message;
    notification.style.display = 'block';
    
    if (autoHide) {
        setTimeout(() => {
            notification.style.display = 'none';
        }, 3000);
    }
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}