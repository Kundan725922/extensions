// Detect if page has complex content
function hasComplexContent() {
    const isScrollable = document.body.scrollHeight > window.innerHeight + 100;
    const hasMedia = document.querySelectorAll('img, video, canvas, svg').length > 5;
    return isScrollable || hasMedia;
}

// Notify background script about page content
try {
    chrome.runtime.sendMessage({ 
        action: "content_detected", 
        complex: hasComplexContent() 
    });
} catch (error) {
    console.log("Content detection message failed:", error);
}


// Listen for commands from background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    
    // Handle stitching command for full page capture
    if (request.action === 'stitch_and_download') {
        console.log("Received stitch command with", request.images.length, "images");
        stitchImagesAndDownload(
            request.images, 
            request.fullHeight, 
            request.viewportWidth, 
            request.viewportHeight
        );
        sendResponse({ success: true });
        return true;
    }
    
    // Handle selective capture overlay
    if (request.action === 'start_selective_capture') {
        startSelectiveCapture();
        sendResponse({ success: true });
        return true;
    }
    
    // Handle image cropping
    if (request.action === 'crop_image') {
        cropAndDownload(request.imageUrl, request.rect);
        sendResponse({ success: true });
        return true;
    }
});


// Stitch all captured images into one tall image
function stitchImagesAndDownload(images, fullHeight, viewportWidth, viewportHeight) {
    if (!images || images.length === 0) {
        alert("Error: No images to stitch!");
        return;
    }

    console.log("Starting stitch process with", images.length, "images...");

    // Create canvas for stitching
    const canvas = document.createElement('canvas');
    canvas.width = viewportWidth;
    canvas.height = fullHeight;
    const ctx = canvas.getContext('2d');

    // Fill with white background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, viewportWidth, fullHeight);

    let imagesLoaded = 0;
    const totalImages = images.length;

    // Load and draw each image
    images.forEach((imgData, index) => {
        const img = new Image();
        
        img.onload = () => {
            console.log(`Drawing image ${index + 1}/${totalImages} at scroll: ${imgData.scroll}`);
            
            // Draw image at its scroll position
            ctx.drawImage(img, 0, imgData.scroll, viewportWidth, viewportHeight);
            imagesLoaded++;

            // When all images are drawn, convert to PNG and download
            if (imagesLoaded === totalImages) {
                console.log("All images processed, creating final image...");
                
                try {
                    // Convert canvas to blob then to data URL
                    canvas.toBlob((blob) => {
                        if (!blob) {
                            console.error("Failed to create blob");
                            alert("Error: Failed to create final image");
                            return;
                        }

                        console.log("Blob created, converting to data URL...");
                        
                        const reader = new FileReader();
                        reader.onloadend = () => {
                            const dataUrl = reader.result;
                            console.log("Data URL created, sending download request...");
                            
                            // Send to background for download
                            chrome.runtime.sendMessage({ 
                                action: 'final_download', 
                                dataUrl: dataUrl, 
                                filename: `screenshot_full_${Date.now()}.png`
                            }, (response) => {
                                if (chrome.runtime.lastError) {
                                    console.error("Download message error:", chrome.runtime.lastError);
                                    alert("Error: Could not initiate download");
                                } else {
                                    console.log("Download request sent successfully");
                                    // Scroll back to top
                                    window.scrollTo(0, 0);
                                    alert("Full page screenshot downloaded!");
                                }
                            });
                        };
                        
                        reader.onerror = () => {
                            console.error("FileReader error");
                            alert("Error: Could not read image data");
                        };
                        
                        reader.readAsDataURL(blob);
                        
                    }, 'image/png', 1.0);
                    
                } catch (error) {
                    console.error("Canvas conversion error:", error);
                    alert("Error creating final image: " + error.message);
                }
            }
        };

        img.onerror = (error) => {
            console.error(`Failed to load image ${index}:`, error);
            alert(`Error: Failed to load image part ${index + 1}`);
        };

        // Load the image
        img.src = imgData.url;
    });
}


// Crop image and download
function cropAndDownload(imageUrl, rect) {
    console.log("Cropping image with rect:", rect);
    
    const img = new Image();
    
    img.onload = () => {
        const canvas = document.createElement('canvas');
        const devicePixelRatio = window.devicePixelRatio || 1;
        
        // Set canvas size to selection size
        canvas.width = rect.width * devicePixelRatio;
        canvas.height = rect.height * devicePixelRatio;
        
        const ctx = canvas.getContext('2d');
        
        // Draw the cropped portion
        ctx.drawImage(
            img,
            rect.left * devicePixelRatio,
            rect.top * devicePixelRatio,
            rect.width * devicePixelRatio,
            rect.height * devicePixelRatio,
            0,
            0,
            canvas.width,
            canvas.height
        );

        // Convert to blob and download
        canvas.toBlob((blob) => {
            if (!blob) {
                alert("Error: Failed to crop image");
                return;
            }

            const reader = new FileReader();
            reader.onloadend = () => {
                const dataUrl = reader.result;
                
                // Send to background for download
                chrome.runtime.sendMessage({ 
                    action: 'final_download', 
                    dataUrl: dataUrl, 
                    filename: `screenshot_selected_${Date.now()}.png`
                }, (response) => {
                    if (chrome.runtime.lastError) {
                        console.error("Download error:", chrome.runtime.lastError);
                        alert("Error: Could not download image");
                    } else {
                        console.log("Selected area downloaded!");
                    }
                });
            };
            reader.readAsDataURL(blob);
            
        }, 'image/png', 1.0);
    };

    img.onerror = () => {
        alert("Error: Failed to load captured image");
    };

    img.src = imageUrl;
}


// Selective capture functionality
function startSelectiveCapture() {
    // Remove any existing overlay
    const existingOverlay = document.getElementById('screenshot-overlay');
    if (existingOverlay) {
        existingOverlay.remove();
    }

    // Create overlay
    const overlay = document.createElement('div');
    overlay.id = 'screenshot-overlay';
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.5);
        cursor: crosshair;
        z-index: 999999;
    `;

    // Create selection box
    const selectionBox = document.createElement('div');
    selectionBox.style.cssText = `
        position: absolute;
        border: 2px dashed #4a90e2;
        background: rgba(74, 144, 226, 0.1);
        display: none;
        box-shadow: 0 0 0 9999px rgba(0, 0, 0, 0.5);
    `;
    overlay.appendChild(selectionBox);

    // Create instruction text
    const instructions = document.createElement('div');
    instructions.style.cssText = `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: rgba(0, 0, 0, 0.9);
        color: white;
        padding: 15px 30px;
        border-radius: 8px;
        font-family: Arial, sans-serif;
        font-size: 14px;
        z-index: 1000000;
        pointer-events: none;
    `;
    instructions.textContent = '🖱️ Click and drag to select area • Press ESC to cancel';
    overlay.appendChild(instructions);

    let startX, startY, isSelecting = false;

    overlay.addEventListener('mousedown', (e) => {
        isSelecting = true;
        startX = e.clientX;
        startY = e.clientY;
        selectionBox.style.left = startX + 'px';
        selectionBox.style.top = startY + 'px';
        selectionBox.style.width = '0px';
        selectionBox.style.height = '0px';
        selectionBox.style.display = 'block';
    });

    overlay.addEventListener('mousemove', (e) => {
        if (!isSelecting) return;

        const currentX = e.clientX;
        const currentY = e.clientY;
        const width = Math.abs(currentX - startX);
        const height = Math.abs(currentY - startY);
        const left = Math.min(currentX, startX);
        const top = Math.min(currentY, startY);

        selectionBox.style.left = left + 'px';
        selectionBox.style.top = top + 'px';
        selectionBox.style.width = width + 'px';
        selectionBox.style.height = height + 'px';
    });

    overlay.addEventListener('mouseup', (e) => {
        if (!isSelecting) return;
        isSelecting = false;

        const endX = e.clientX;
        const endY = e.clientY;
        const width = Math.abs(endX - startX);
        const height = Math.abs(endY - startY);

        // Minimum selection size
        if (width < 10 || height < 10) {
            overlay.remove();
            alert("Selection too small. Please select a larger area.");
            return;
        }

        const left = Math.min(endX, startX);
        const top = Math.min(endY, startY);

        // Remove overlay first
        overlay.remove();

        // Capture the selected area
        chrome.runtime.sendMessage({
            action: 'capture_and_crop',
            rect: { left, top, width, height }
        });
    });

    // ESC key to cancel
    const escHandler = (e) => {
        if (e.key === 'Escape') {
            overlay.remove();
            document.removeEventListener('keydown', escHandler);
        }
    };
    document.addEventListener('keydown', escHandler);

    document.body.appendChild(overlay);
}