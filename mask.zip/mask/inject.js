// Enhanced GhostMask Content Script with Timezone & Language Spoofing
(function() {
    'use strict';
    
    // Request identity from background script
    chrome.runtime.sendMessage({action: "get_identity"}, (response) => {
        if (!response || !response.identity) {
            console.warn("GhostMask: No identity available");
            return;
        }
        
        const id = response.identity;
        const timezone = response.timezone || "America/New_York";
        const languages = response.languages || ["en-US", "en"];
        
        // ========== 1. SYSTEM DETAILS SPOOFING ==========
        try {
            Object.defineProperties(navigator, {
                platform: { 
                    get: () => id.os,
                    configurable: true
                },
                hardwareConcurrency: { 
                    get: () => id.cores,
                    configurable: true
                },
                deviceMemory: { 
                    get: () => id.mem,
                    configurable: true
                },
                userAgent: { 
                    get: () => id.ua,
                    configurable: true
                },
                // Language spoofing
                language: {
                    get: () => languages[0],
                    configurable: true
                },
                languages: {
                    get: () => languages,
                    configurable: true
                }
            });
        } catch (e) {
            console.warn("GhostMask: Navigator spoofing failed", e);
        }
        
        // ========== 2. TIMEZONE SPOOFING ==========
        try {
            // Override Date object to use spoofed timezone
            const originalDate = Date;
            const timezoneOffset = getTimezoneOffset(timezone);
            
            window.Date = class extends originalDate {
                constructor(...args) {
                    if (args.length === 0) {
                        super();
                    } else {
                        super(...args);
                    }
                }
                
                getTimezoneOffset() {
                    return timezoneOffset;
                }
                
                toString() {
                    return this.toLocaleString('en-US', { timeZone: timezone });
                }
                
                toTimeString() {
                    const str = super.toTimeString();
                    return str.replace(/GMT[+-]\d{4}.*/, getTimezoneString(timezone));
                }
                
                toLocaleString(...args) {
                    if (args.length === 0 || !args[1]?.timeZone) {
                        return super.toLocaleString(args[0], { ...args[1], timeZone: timezone });
                    }
                    return super.toLocaleString(...args);
                }
            };
            
            // Copy static methods
            Object.setPrototypeOf(window.Date, originalDate);
            window.Date.now = originalDate.now.bind(originalDate);
            window.Date.parse = originalDate.parse.bind(originalDate);
            window.Date.UTC = originalDate.UTC.bind(originalDate);
            
            // Override Intl.DateTimeFormat
            const OriginalDateTimeFormat = Intl.DateTimeFormat;
            Intl.DateTimeFormat = function(...args) {
                if (!args[1] || !args[1].timeZone) {
                    args[1] = { ...args[1], timeZone: timezone };
                }
                return new OriginalDateTimeFormat(...args);
            };
            Object.setPrototypeOf(Intl.DateTimeFormat, OriginalDateTimeFormat);
            
            console.log("🕒 Timezone Spoofed:", timezone);
        } catch (e) {
            console.warn("GhostMask: Timezone spoofing failed", e);
        }
        
        // ========== 3. GPS LOCATION SPOOFING ==========
        chrome.storage.local.get('spoofedLocation', (data) => {
            if (!data.spoofedLocation) return;
            
            const fakeLocation = data.spoofedLocation;
            
            navigator.geolocation.getCurrentPosition = function(success, error, options) {
                setTimeout(() => {
                    success({
                        coords: {
                            latitude: fakeLocation.lat,
                            longitude: fakeLocation.lng,
                            accuracy: fakeLocation.accuracy,
                            altitude: null,
                            altitudeAccuracy: null,
                            heading: null,
                            speed: null
                        },
                        timestamp: Date.now()
                    });
                }, Math.random() * 100 + 50);
            };
            
            navigator.geolocation.watchPosition = function(success, error, options) {
                const watchId = Math.floor(Math.random() * 1000000);
                
                setTimeout(() => {
                    success({
                        coords: {
                            latitude: fakeLocation.lat,
                            longitude: fakeLocation.lng,
                            accuracy: fakeLocation.accuracy,
                            altitude: null,
                            altitudeAccuracy: null,
                            heading: null,
                            speed: null
                        },
                        timestamp: Date.now()
                    });
                }, Math.random() * 100 + 50);
                
                return watchId;
            };
            
            navigator.geolocation.clearWatch = function(watchId) {};
            
            console.log("📍 GPS Spoofed:", fakeLocation.city);
        });
        
        // ========== 4. ENHANCED CANVAS FINGERPRINT PROTECTION ==========
        try {
            const originalGetContext = HTMLCanvasElement.prototype.getContext;
            const originalToDataURL = HTMLCanvasElement.prototype.toDataURL;
            const originalToBlob = HTMLCanvasElement.prototype.toBlob;
            
            // Add noise function
            const addNoise = (context) => {
                const imageData = context.getImageData(0, 0, context.canvas.width, context.canvas.height);
                const pixels = imageData.data;
                
                // Add subtle random noise (±1-2 RGB values)
                for (let i = 0; i < pixels.length; i += 4) {
                    pixels[i] = Math.min(255, Math.max(0, pixels[i] + (Math.random() - 0.5) * 2));
                    pixels[i+1] = Math.min(255, Math.max(0, pixels[i+1] + (Math.random() - 0.5) * 2));
                    pixels[i+2] = Math.min(255, Math.max(0, pixels[i+2] + (Math.random() - 0.5) * 2));
                }
                
                context.putImageData(imageData, 0, 0);
            };
            
            HTMLCanvasElement.prototype.getContext = function(type, ...args) {
                const context = originalGetContext.apply(this, [type, ...args]);
                
                if (context && type === '2d') {
                    const originalFillText = context.fillText;
                    const originalStrokeText = context.strokeText;
                    
                    context.fillText = function(...textArgs) {
                        const originalShadowBlur = context.shadowBlur;
                        context.shadowBlur = Math.random() * 0.1;
                        const result = originalFillText.apply(this, textArgs);
                        context.shadowBlur = originalShadowBlur;
                        return result;
                    };
                    
                    context.strokeText = function(...textArgs) {
                        const originalShadowBlur = context.shadowBlur;
                        context.shadowBlur = Math.random() * 0.1;
                        const result = originalStrokeText.apply(this, textArgs);
                        context.shadowBlur = originalShadowBlur;
                        return result;
                    };
                }
                
                return context;
            };
            
            // Protect toDataURL
            HTMLCanvasElement.prototype.toDataURL = function(...args) {
                const context = this.getContext('2d');
                if (context) {
                    addNoise(context);
                }
                return originalToDataURL.apply(this, args);
            };
            
            // Protect toBlob
            HTMLCanvasElement.prototype.toBlob = function(callback, ...args) {
                const context = this.getContext('2d');
                if (context) {
                    addNoise(context);
                }
                return originalToBlob.apply(this, [callback, ...args]);
            };
            
            console.log("🎨 Canvas fingerprint protection active");
        } catch (e) {
            console.warn("GhostMask: Canvas protection failed", e);
        }
        
        // ========== 5. WEBGL FINGERPRINT PROTECTION ==========
        try {
            const getParameterProxied = WebGLRenderingContext.prototype.getParameter;
            WebGLRenderingContext.prototype.getParameter = function(parameter) {
                // Spoof WebGL vendor and renderer
                if (parameter === 37445) { // UNMASKED_VENDOR_WEBGL
                    return "Intel Inc.";
                }
                if (parameter === 37446) { // UNMASKED_RENDERER_WEBGL
                    return "Intel Iris OpenGL Engine";
                }
                return getParameterProxied.apply(this, [parameter]);
            };
            
            console.log("🎮 WebGL fingerprint protection active");
        } catch (e) {
            console.warn("GhostMask: WebGL protection failed", e);
        }
        
        // ========== 6. AUDIO CONTEXT FINGERPRINT PROTECTION ==========
        try {
            const OriginalAudioContext = window.AudioContext || window.webkitAudioContext;
            if (OriginalAudioContext) {
                const ProxiedAudioContext = new Proxy(OriginalAudioContext, {
                    construct(target, args) {
                        const context = new target(...args);
                        const originalCreateOscillator = context.createOscillator.bind(context);
                        
                        context.createOscillator = function() {
                            const oscillator = originalCreateOscillator();
                            const originalStart = oscillator.start.bind(oscillator);
                            
                            oscillator.start = function(when) {
                                // Add tiny random frequency shift
                                oscillator.frequency.value += (Math.random() - 0.5) * 0.001;
                                return originalStart(when);
                            };
                            
                            return oscillator;
                        };
                        
                        return context;
                    }
                });
                
                window.AudioContext = ProxiedAudioContext;
                if (window.webkitAudioContext) {
                    window.webkitAudioContext = ProxiedAudioContext;
                }
                
                console.log("🔊 Audio fingerprint protection active");
            }
        } catch (e) {
            console.warn("GhostMask: Audio protection failed", e);
        }
        
        // ========== 7. ENHANCED ANTI-SKIMMING PROTECTION ==========
        document.addEventListener('keydown', (event) => {
            const target = event.target;
            if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
                // Stop propagation for sensitive fields
                if (target.type === 'password' || 
                    target.type === 'email' ||
                    target.autocomplete === 'cc-number' ||
                    target.autocomplete === 'cc-csc' ||
                    target.name?.toLowerCase().includes('card') ||
                    target.name?.toLowerCase().includes('cvv')) {
                    event.stopPropagation();
                }
            }
        }, true);
        
        // ========== 8. FONT FINGERPRINT PROTECTION ==========
        try {
            // Override font measurement to add slight variations
            const originalMeasureText = CanvasRenderingContext2D.prototype.measureText;
            CanvasRenderingContext2D.prototype.measureText = function(text) {
                const metrics = originalMeasureText.apply(this, [text]);
                const noise = (Math.random() - 0.5) * 0.01;
                
                return new Proxy(metrics, {
                    get(target, prop) {
                        if (prop === 'width') {
                            return target.width + noise;
                        }
                        return target[prop];
                    }
                });
            };
            
            console.log("🔤 Font fingerprint protection active");
        } catch (e) {
            console.warn("GhostMask: Font protection failed", e);
        }
        
        // ========== 9. SCREEN RESOLUTION SPOOFING ==========
        try {
            // Add slight noise to screen dimensions
            const screenNoise = {
                width: Math.floor((Math.random() - 0.5) * 20),
                height: Math.floor((Math.random() - 0.5) * 20)
            };
            
            Object.defineProperties(screen, {
                width: {
                    get: () => 1920 + screenNoise.width,
                    configurable: true
                },
                height: {
                    get: () => 1080 + screenNoise.height,
                    configurable: true
                },
                availWidth: {
                    get: () => 1920 + screenNoise.width,
                    configurable: true
                },
                availHeight: {
                    get: () => 1040 + screenNoise.height,
                    configurable: true
                }
            });
            
            console.log("🖥️ Screen resolution spoofing active");
        } catch (e) {
            console.warn("GhostMask: Screen spoofing failed", e);
        }
        
        console.log("🛡️ GhostMask Protection Active:", id.device);
        console.log("🌍 Location:", fakeLocation?.city || "Not set");
        console.log("🗣️ Languages:", languages.join(", "));
    });
    
    // Helper function to get timezone offset
    function getTimezoneOffset(tz) {
        const timezoneOffsets = {
            'America/New_York': 300,
            'America/Chicago': 360,
            'America/Los_Angeles': 480,
            'America/Toronto': 300,
            'Europe/London': 0,
            'Europe/Paris': -60,
            'Europe/Berlin': -60,
            'Europe/Madrid': -60,
            'Europe/Amsterdam': -60,
            'Europe/Stockholm': -60,
            'Asia/Tokyo': -540,
            'Asia/Seoul': -540,
            'Asia/Singapore': -480,
            'Asia/Kolkata': -330,
            'Australia/Sydney': -660,
            'Australia/Melbourne': -660
        };
        return timezoneOffsets[tz] || 0;
    }
    
    // Helper function to get timezone string
    function getTimezoneString(tz) {
        const tzStrings = {
            'America/New_York': 'GMT-0500 (Eastern Standard Time)',
            'America/Chicago': 'GMT-0600 (Central Standard Time)',
            'America/Los_Angeles': 'GMT-0800 (Pacific Standard Time)',
            'America/Toronto': 'GMT-0500 (Eastern Standard Time)',
            'Europe/London': 'GMT+0000 (Greenwich Mean Time)',
            'Europe/Paris': 'GMT+0100 (Central European Time)',
            'Europe/Berlin': 'GMT+0100 (Central European Time)',
            'Asia/Tokyo': 'GMT+0900 (Japan Standard Time)',
            'Asia/Singapore': 'GMT+0800 (Singapore Time)',
            'Australia/Sydney': 'GMT+1100 (Australian Eastern Time)'
        };
        return tzStrings[tz] || 'GMT+0000';
    }
})();