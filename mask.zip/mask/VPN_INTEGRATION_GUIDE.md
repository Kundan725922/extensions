# 🌐 VPN Integration Guide for GhostMask

## Overview
This guide explains how to integrate VPN functionality into GhostMask for complete IP privacy.

---

## 🎯 Integration Options

### Option 1: Proxy API (Recommended)
Use Chrome's built-in proxy API to route traffic through VPN servers.

#### Setup Steps:
1. Request `proxy` permission in manifest.json (already added as optional)
2. Configure SOCKS5/HTTP proxy settings
3. Add VPN server list
4. Implement connection logic

#### Example Code:
```javascript
// In background.js
async function connectToVPN(server) {
    const config = {
        mode: "fixed_servers",
        rules: {
            singleProxy: {
                scheme: "socks5",
                host: server.ip,
                port: server.port
            },
            bypassList: ["localhost", "127.0.0.1"]
        }
    };
    
    await chrome.proxy.settings.set({
        value: config,
        scope: 'regular'
    });
    
    console.log("✅ Connected to VPN:", server.name);
}

// VPN Server List (Example)
const VPN_SERVERS = [
    { name: "ExpressVPN - USA", ip: "proxy.expressvpn.com", port: 1080 },
    { name: "NordVPN - UK", ip: "proxy.nordvpn.com", port: 1080 },
    // Add more servers
];
```

---

### Option 2: Native Messaging with VPN Apps
Communicate directly with installed VPN applications.

#### Supported VPNs:
- ExpressVPN (native app)
- NordVPN (native app)
- ProtonVPN (native app)

#### Example Flow:
```
GhostMask Extension → Native Messaging → VPN App → Connection
```

---

### Option 3: WebExtension API + VPN Provider APIs
Use VPN provider APIs for programmatic control.

#### ExpressVPN API Example:
```javascript
// Requires ExpressVPN subscription with API access
const EXPRESS_API_KEY = "your_api_key";

async function connectExpressVPN(location) {
    const response = await fetch('https://api.expressvpn.com/connect', {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${EXPRESS_API_KEY}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            location: location,
            protocol: 'auto'
        })
    });
    
    return response.json();
}
```

---

## 🔧 Implementation Roadmap

### Phase 1: Proxy Detection
```javascript
// Check if user has VPN already running
async function detectExistingVPN() {
    try {
        const ipCheck = await fetch('https://api.ipify.org?format=json');
        const data = await ipCheck.json();
        
        // Check if IP matches any VPN ranges
        const isVPN = await checkIfVPNIP(data.ip);
        
        return {
            detected: isVPN,
            ip: data.ip
        };
    } catch (e) {
        return { detected: false, error: e };
    }
}
```

### Phase 2: Manual Proxy Configuration
```javascript
// Let users input their own proxy settings
async function setCustomProxy(proxyConfig) {
    await chrome.storage.local.set({ customProxy: proxyConfig });
    
    await chrome.proxy.settings.set({
        value: {
            mode: "fixed_servers",
            rules: {
                singleProxy: {
                    scheme: proxyConfig.protocol, // "http", "https", "socks4", "socks5"
                    host: proxyConfig.host,
                    port: parseInt(proxyConfig.port)
                }
            }
        },
        scope: 'regular'
    });
}
```

### Phase 3: VPN Provider Integration
```javascript
// Integrate with major VPN providers
class VPNManager {
    constructor() {
        this.providers = {
            'expressvpn': new ExpressVPNProvider(),
            'nordvpn': new NordVPNProvider(),
            'protonvpn': new ProtonVPNProvider()
        };
        this.currentProvider = null;
    }
    
    async connect(provider, server) {
        if (!this.providers[provider]) {
            throw new Error('Unsupported VPN provider');
        }
        
        this.currentProvider = provider;
        return await this.providers[provider].connect(server);
    }
    
    async disconnect() {
        if (this.currentProvider) {
            return await this.providers[this.currentProvider].disconnect();
        }
    }
    
    async getStatus() {
        if (this.currentProvider) {
            return await this.providers[this.currentProvider].getStatus();
        }
        return { connected: false };
    }
}
```

---

## 🛠️ Enhanced Features to Add

### 1. IP Leak Detection
```javascript
async function checkForIPLeaks() {
    const tests = {
        webrtc: await testWebRTCLeak(),
        dns: await testDNSLeak(),
        ipv6: await testIPv6Leak()
    };
    
    return {
        safe: Object.values(tests).every(t => !t.leaked),
        details: tests
    };
}

async function testWebRTCLeak() {
    // Already handled by WebRTC blocking
    return { leaked: false, method: 'blocked' };
}

async function testDNSLeak() {
    try {
        const response = await fetch('https://dnsleaktest.com/api/check');
        const data = await response.json();
        // Check if DNS servers match VPN location
        return { leaked: false, dns: data };
    } catch (e) {
        return { leaked: true, error: e };
    }
}
```

### 2. Kill Switch
```javascript
// Block all traffic if VPN disconnects
class KillSwitch {
    constructor() {
        this.enabled = false;
        this.isActive = false;
    }
    
    enable() {
        this.enabled = true;
        chrome.webRequest.onBeforeRequest.addListener(
            this.blockRequest.bind(this),
            { urls: ["<all_urls>"] },
            ["blocking"]
        );
    }
    
    blockRequest(details) {
        if (this.isActive) {
            console.log("🛑 Kill Switch: Blocking request while VPN disconnected");
            return { cancel: true };
        }
        return { cancel: false };
    }
    
    activate() {
        if (this.enabled) {
            this.isActive = true;
            chrome.notifications.create({
                type: 'basic',
                iconUrl: 'icon128.png',
                title: 'VPN Disconnected',
                message: 'Kill Switch activated - Internet blocked for safety'
            });
        }
    }
    
    deactivate() {
        this.isActive = false;
    }
}
```

### 3. Auto-Reconnect
```javascript
class AutoReconnect {
    constructor(vpnManager) {
        this.vpnManager = vpnManager;
        this.maxRetries = 3;
        this.retryDelay = 5000; // 5 seconds
    }
    
    async monitor() {
        setInterval(async () => {
            const status = await this.vpnManager.getStatus();
            
            if (!status.connected) {
                console.log("⚠️ VPN disconnected, attempting reconnect...");
                await this.reconnect();
            }
        }, 10000); // Check every 10 seconds
    }
    
    async reconnect(retries = 0) {
        if (retries >= this.maxRetries) {
            console.error("❌ Max reconnection attempts reached");
            return false;
        }
        
        try {
            await this.vpnManager.connect();
            console.log("✅ VPN reconnected successfully");
            return true;
        } catch (e) {
            console.log(`Retry ${retries + 1}/${this.maxRetries}...`);
            await new Promise(resolve => setTimeout(resolve, this.retryDelay));
            return await this.reconnect(retries + 1);
        }
    }
}
```

---

## 📊 UI Updates for VPN Features

### Enhanced Popup UI
```html
<div class="vpn-control-panel">
    <div class="vpn-status">
        <span id="vpn-indicator" class="status-dot disconnected"></span>
        <span id="vpn-status-text">Disconnected</span>
    </div>
    
    <select id="vpn-provider">
        <option value="">Select VPN Provider...</option>
        <option value="expressvpn">ExpressVPN</option>
        <option value="nordvpn">NordVPN</option>
        <option value="protonvpn">ProtonVPN</option>
        <option value="custom">Custom Proxy</option>
    </select>
    
    <select id="vpn-server">
        <option value="">Select Server...</option>
        <!-- Populated dynamically based on provider -->
    </select>
    
    <button id="vpn-connect" class="vpn-button">
        Connect to VPN
    </button>
    
    <div class="vpn-info">
        <div class="info-row">
            <span class="label">Your IP:</span>
            <span id="current-ip">Checking...</span>
        </div>
        <div class="info-row">
            <span class="label">VPN IP:</span>
            <span id="vpn-ip">Not connected</span>
        </div>
        <div class="info-row">
            <span class="label">Encryption:</span>
            <span id="encryption">—</span>
        </div>
    </div>
    
    <div class="vpn-features">
        <label>
            <input type="checkbox" id="kill-switch"> Kill Switch
        </label>
        <label>
            <input type="checkbox" id="auto-reconnect"> Auto-Reconnect
        </label>
        <label>
            <input type="checkbox" id="dns-leak-protection"> DNS Leak Protection
        </label>
    </div>
</div>
```

---

## 🔐 Security Considerations

### 1. Credential Storage
```javascript
// NEVER store VPN credentials in plain text
// Use Chrome's secure storage
async function storeVPNCredentials(username, password) {
    // Hash password before storing
    const hashedPassword = await hashPassword(password);
    
    await chrome.storage.local.set({
        vpnCredentials: {
            username: username,
            password: hashedPassword,
            stored: Date.now()
        }
    });
}

async function hashPassword(password) {
    const encoder = new TextEncoder();
    const data = encoder.encode(password);
    const hash = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hash))
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
}
```

### 2. Certificate Validation
```javascript
// Ensure VPN connection uses valid certificates
async function validateCertificate(hostname) {
    try {
        const response = await fetch(`https://${hostname}`, {
            method: 'HEAD'
        });
        return response.ok;
    } catch (e) {
        console.error("Certificate validation failed:", e);
        return false;
    }
}
```

---

## 📝 Required Permissions Update

Add to manifest.json:
```json
{
  "permissions": [
    "proxy",
    "webRequest",
    "webRequestBlocking",
    "notifications"
  ],
  "host_permissions": [
    "https://api.ipify.org/*",
    "https://dnsleaktest.com/*"
  ]
}
```

---

## 🚀 Testing Checklist

### VPN Connection Tests:
- [ ] Connect to VPN successfully
- [ ] Disconnect from VPN
- [ ] Switch between servers
- [ ] Auto-reconnect on failure
- [ ] Kill switch activation
- [ ] DNS leak prevention
- [ ] WebRTC leak prevention
- [ ] IPv6 leak prevention

### IP Verification:
- [ ] Check IP before connection
- [ ] Verify IP changes after connection
- [ ] Confirm IP matches VPN server location
- [ ] Test with multiple IP checking services

### Performance:
- [ ] Measure connection latency
- [ ] Check page load speeds
- [ ] Monitor bandwidth usage
- [ ] Test with video streaming
- [ ] Test with large downloads

---

## 📚 Recommended Resources

### VPN Provider APIs:
- ExpressVPN: https://www.expressvpn.com/support/vpn-setup/app-api/
- NordVPN: https://nordvpn.com/api/
- ProtonVPN: https://protonvpn.com/support/api/

### Testing Tools:
- https://browserleaks.com/ip
- https://ipleak.net/
- https://dnsleaktest.com/
- https://www.doileak.com/

### Security Standards:
- OpenVPN Protocol
- WireGuard Protocol
- IKEv2/IPsec

---

## 💡 Pro Tips

1. **Start Simple**: Begin with manual proxy configuration
2. **Add One Provider**: Master ExpressVPN or NordVPN first
3. **Test Thoroughly**: Use leak testing tools extensively
4. **User Education**: Add tutorials for setting up VPNs
5. **Fallback Options**: Always have a way to disable if issues occur

---

## 🎯 Next Steps

1. Implement basic proxy configuration UI
2. Add IP detection and display
3. Create VPN server list for one provider
4. Build connection/disconnection logic
5. Add leak detection
6. Implement kill switch
7. Add auto-reconnect
8. Test extensively
9. Document user setup process
10. Release VPN-enabled version!

---

**Remember**: VPN integration is complex. Start small, test thoroughly, and prioritize user safety over features!