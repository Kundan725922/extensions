function refreshUI() {
    chrome.storage.local.get([
        'currentIdentity', 
        'spoofedLocation', 
        'spoofedTimezone', 
        'spoofedLanguages',
        'vpnProvider'
    ], (data) => {
        // Update device info
        if (data.currentIdentity) {
            const id = data.currentIdentity;
            document.getElementById('os').textContent = id.os;
            document.getElementById('device').textContent = id.device || 'Unknown Device';
            document.getElementById('hw').textContent = `${id.cores} Cores / ${id.mem}GB RAM`;
        } else {
            document.getElementById('os').textContent = 'Not initialized';
            document.getElementById('device').textContent = 'Click button to start';
            document.getElementById('hw').textContent = '—';
        }
        
        // Update location
        if (data.spoofedLocation) {
            const loc = data.spoofedLocation;
            document.getElementById('location').textContent = loc.city;
            document.getElementById('coords').textContent = 
                `${loc.lat.toFixed(4)}°, ${loc.lng.toFixed(4)}°`;
        } else {
            document.getElementById('location').textContent = 'Not set';
            document.getElementById('coords').textContent = '—';
        }
        
        // Update timezone
        if (data.spoofedTimezone) {
            document.getElementById('timezone').textContent = data.spoofedTimezone;
        } else {
            document.getElementById('timezone').textContent = 'System default';
        }
        
        // Update languages
        if (data.spoofedLanguages && data.spoofedLanguages.length > 0) {
            document.getElementById('languages').textContent = data.spoofedLanguages.join(', ');
        } else {
            document.getElementById('languages').textContent = 'en-US';
        }
        
        // Update VPN status
        if (data.vpnProvider) {
            document.getElementById('vpn').textContent = '🔒 ' + data.vpnProvider;
            document.getElementById('vpn').style.background = 
                'linear-gradient(135deg, #10b981 0%, #059669 100%)';
        } else {
            document.getElementById('vpn').textContent = '⚠️ Install VPN (Recommended)';
            document.getElementById('vpn').style.background = '#64748b';
        }
    });
}

// Initial load
document.addEventListener('DOMContentLoaded', refreshUI);

// Rotate identity button
document.getElementById('rotate').onclick = () => {
    const btn = document.getElementById('rotate');
    const originalText = btn.textContent;
    btn.textContent = '⏳ Rotating...';
    btn.disabled = true;
    
    chrome.runtime.sendMessage({ action: "rotate_now" }, (response) => {
        // Add slight delay for UX
        setTimeout(() => {
            refreshUI();
            btn.textContent = '✅ Identity Changed!';
            
            // Reset button after 2 seconds
            setTimeout(() => {
                btn.textContent = originalText;
                btn.disabled = false;
            }, 2000);
        }, 500);
    });
};