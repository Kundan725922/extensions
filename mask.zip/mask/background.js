// Enhanced GhostMask with VPN, Timezone, Language Spoofing
const PERSONAS = [
    // === NORTH AMERICA ===
    { 
        os: "MacIntel", 
        ua: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36", 
        cores: 8, 
        mem: 16,
        device: "MacBook Pro M1",
        location: { lat: 40.7128, lng: -74.0060, city: "New York, USA" },
        timezone: "America/New_York",
        languages: ["en-US", "en"],
        vpnProvider: "ExpressVPN - USA East"
    },
    {
        os: "Win32",
        ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        cores: 16,
        mem: 32,
        device: "Gaming Desktop",
        location: { lat: 34.0522, lng: -118.2437, city: "Los Angeles, USA" },
        timezone: "America/Los_Angeles",
        languages: ["en-US", "en", "es-US"],
        vpnProvider: "NordVPN - USA West"
    },
    {
        os: "MacIntel",
        ua: "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5_0) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15",
        cores: 10,
        mem: 32,
        device: "iMac 27-inch",
        location: { lat: 37.7749, lng: -122.4194, city: "San Francisco, USA" },
        timezone: "America/Los_Angeles",
        languages: ["en-US", "en"],
        vpnProvider: "Surfshark - California"
    },
    {
        os: "Win32",
        ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0",
        cores: 6,
        mem: 16,
        device: "Dell Laptop",
        location: { lat: 41.8781, lng: -87.6298, city: "Chicago, USA" },
        timezone: "America/Chicago",
        languages: ["en-US", "en"],
        vpnProvider: "ProtonVPN - Illinois"
    },
    {
        os: "Win32",
        ua: "Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0",
        cores: 12,
        mem: 24,
        device: "Surface Studio",
        location: { lat: 43.6532, lng: -79.3832, city: "Toronto, Canada" },
        timezone: "America/Toronto",
        languages: ["en-CA", "en", "fr-CA"],
        vpnProvider: "ExpressVPN - Canada"
    },
    
    // === EUROPE ===
    { 
        os: "Win32", 
        ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36", 
        cores: 4, 
        mem: 8,
        device: "HP Pavilion",
        location: { lat: 51.5074, lng: -0.1278, city: "London, UK" },
        timezone: "Europe/London",
        languages: ["en-GB", "en"],
        vpnProvider: "NordVPN - UK London"
    },
    {
        os: "Win32",
        ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        cores: 8,
        mem: 16,
        device: "Lenovo ThinkPad",
        location: { lat: 48.8566, lng: 2.3522, city: "Paris, France" },
        timezone: "Europe/Paris",
        languages: ["fr-FR", "fr", "en-GB"],
        vpnProvider: "Surfshark - France"
    },
    {
        os: "Linux x86_64",
        ua: "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        cores: 6,
        mem: 12,
        device: "System76 Laptop",
        location: { lat: 52.5200, lng: 13.4050, city: "Berlin, Germany" },
        timezone: "Europe/Berlin",
        languages: ["de-DE", "de", "en-US"],
        vpnProvider: "ProtonVPN - Germany"
    },
    {
        os: "Win32",
        ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
        cores: 8,
        mem: 16,
        device: "ASUS ROG",
        location: { lat: 41.3851, lng: 2.1734, city: "Barcelona, Spain" },
        timezone: "Europe/Madrid",
        languages: ["es-ES", "ca", "en-GB"],
        vpnProvider: "ExpressVPN - Spain"
    },
    {
        os: "Linux x86_64",
        ua: "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:115.0) Gecko/20100101 Firefox/115.0",
        cores: 4,
        mem: 8,
        device: "Ubuntu Desktop",
        location: { lat: 52.3676, lng: 4.9041, city: "Amsterdam, Netherlands" },
        timezone: "Europe/Amsterdam",
        languages: ["nl-NL", "en-GB"],
        vpnProvider: "NordVPN - Netherlands"
    },
    {
        os: "MacIntel",
        ua: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15",
        cores: 8,
        mem: 16,
        device: "MacBook Pro",
        location: { lat: 59.3293, lng: 18.0686, city: "Stockholm, Sweden" },
        timezone: "Europe/Stockholm",
        languages: ["sv-SE", "en-GB"],
        vpnProvider: "Surfshark - Sweden"
    },
    
    // === ASIA ===
    { 
        os: "Linux x86_64", 
        ua: "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:115.0) Gecko/20100101 Firefox/115.0", 
        cores: 6, 
        mem: 12,
        device: "Custom Build PC",
        location: { lat: 35.6762, lng: 139.6503, city: "Tokyo, Japan" },
        timezone: "Asia/Tokyo",
        languages: ["ja-JP", "ja", "en-US"],
        vpnProvider: "ExpressVPN - Japan"
    },
    {
        os: "Win32",
        ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        cores: 8,
        mem: 16,
        device: "Samsung Laptop",
        location: { lat: 37.5665, lng: 126.9780, city: "Seoul, South Korea" },
        timezone: "Asia/Seoul",
        languages: ["ko-KR", "ko", "en-US"],
        vpnProvider: "NordVPN - South Korea"
    },
    {
        os: "MacIntel",
        ua: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        cores: 8,
        mem: 16,
        device: "MacBook Pro",
        location: { lat: 1.3521, lng: 103.8198, city: "Singapore" },
        timezone: "Asia/Singapore",
        languages: ["en-SG", "zh-CN", "ms-MY"],
        vpnProvider: "ProtonVPN - Singapore"
    },
    {
        os: "Win32",
        ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        cores: 6,
        mem: 12,
        device: "HP Laptop",
        location: { lat: 28.6139, lng: 77.2090, city: "New Delhi, India" },
        timezone: "Asia/Kolkata",
        languages: ["en-IN", "hi-IN"],
        vpnProvider: "Surfshark - India"
    },
    
    // === OCEANIA ===
    {
        os: "MacIntel",
        ua: "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        cores: 4,
        mem: 8,
        device: "MacBook Air",
        location: { lat: -33.8688, lng: 151.2093, city: "Sydney, Australia" },
        timezone: "Australia/Sydney",
        languages: ["en-AU", "en"],
        vpnProvider: "ExpressVPN - Australia"
    },
    {
        os: "Win32",
        ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        cores: 6,
        mem: 16,
        device: "Dell XPS",
        location: { lat: -37.8136, lng: 144.9631, city: "Melbourne, Australia" },
        timezone: "Australia/Melbourne",
        languages: ["en-AU", "en"],
        vpnProvider: "NordVPN - Australia"
    }
];

// VPN Configuration (for future proxy integration)
const VPN_CONFIGS = {
    enabled: false,
    autoConnect: true,
    protocol: "OpenVPN", // or "WireGuard"
    dnsLeakProtection: true,
    killSwitch: true
};

// Enhanced rotation with timezone and language support
async function rotateIdentity() {
    const newID = PERSONAS[Math.floor(Math.random() * PERSONAS.length)];
    const timestamp = new Date().toDateString();
    
    // Add small random offset to location (within ~5km radius)
    const latOffset = (Math.random() - 0.5) * 0.05;
    const lngOffset = (Math.random() - 0.5) * 0.05;
    
    const personalizedLocation = {
        lat: newID.location.lat + latOffset,
        lng: newID.location.lng + lngOffset,
        city: newID.location.city,
        accuracy: Math.floor(Math.random() * 50) + 10
    };
    
    await chrome.storage.local.set({ 
        currentIdentity: newID,
        spoofedLocation: personalizedLocation,
        spoofedTimezone: newID.timezone,
        spoofedLanguages: newID.languages,
        vpnProvider: newID.vpnProvider,
        lastUpdate: timestamp 
    });
    
    console.log("🔄 Identity Rotated:", newID.device, personalizedLocation.city);
    console.log("🌐 VPN:", newID.vpnProvider);
    console.log("🕒 Timezone:", newID.timezone);
    console.log("🗣️ Languages:", newID.languages.join(", "));
    
    return newID;
}

// 1. Enhanced WebRTC Leak Protection
try {
    chrome.privacy.network.webRTCIPHandlingPolicy.set({
        value: 'disable_non_proxied_udp'
    });
    console.log("✅ WebRTC leak protection enabled");
} catch (e) {
    console.warn("⚠️ WebRTC privacy setting not available:", e);
}

// 2. DNT (Do Not Track) Header
try {
    chrome.privacy.websites.doNotTrackEnabled.set({ value: true });
    console.log("✅ Do Not Track enabled");
} catch (e) {
    console.warn("⚠️ DNT setting not available:", e);
}

// 3. Third-party cookies blocking
try {
    chrome.privacy.websites.thirdPartyCookiesAllowed.set({ value: false });
    console.log("✅ Third-party cookies blocked");
} catch (e) {
    console.warn("⚠️ Cookie setting not available:", e);
}

// 4. Referrer header spoofing
try {
    chrome.privacy.websites.referrersEnabled.set({ value: false });
    console.log("✅ Referrer headers disabled");
} catch (e) {
    console.warn("⚠️ Referrer setting not available:", e);
}

// 5. Initialize identity on install
chrome.runtime.onInstalled.addListener(async () => {
    await rotateIdentity();
    console.log("🛡️ GhostMask Enhanced Protection Active");
});

// 6. Check and rotate daily
chrome.runtime.onStartup.addListener(async () => {
    const data = await chrome.storage.local.get(['lastUpdate', 'currentIdentity']);
    if (!data.currentIdentity || data.lastUpdate !== new Date().toDateString()) {
        await rotateIdentity();
    }
});

// 7. Message handling with new features
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "rotate_now") {
        rotateIdentity().then((newID) => {
            sendResponse({
                status: "done", 
                identity: newID,
                timezone: newID.timezone,
                languages: newID.languages,
                vpn: newID.vpnProvider
            });
        });
        return true; 
    }
    
    if (request.action === "get_identity") {
        chrome.storage.local.get([
            'currentIdentity', 
            'spoofedTimezone', 
            'spoofedLanguages',
            'vpnProvider'
        ], (data) => {
            sendResponse({
                identity: data.currentIdentity || PERSONAS[0],
                timezone: data.spoofedTimezone,
                languages: data.spoofedLanguages,
                vpn: data.vpnProvider
            });
        });
        return true;
    }
    
    // New: VPN status check (placeholder for future implementation)
    if (request.action === "check_vpn") {
        sendResponse({
            connected: VPN_CONFIGS.enabled,
            provider: "Not connected (Install ExpressVPN/NordVPN)"
        });
        return true;
    }
});

// 8. Header modification for enhanced privacy
chrome.webRequest.onBeforeSendHeaders.addListener(
    (details) => {
        const headers = details.requestHeaders;
        
        // Remove potentially identifying headers
        const headersToRemove = [
            'X-Client-Data',
            'X-Chrome-UMA-Enabled',
            'X-Chrome-Variations'
        ];
        
        return {
            requestHeaders: headers.filter(h => 
                !headersToRemove.includes(h.name)
            )
        };
    },
    { urls: ["<all_urls>"] },
    ["blocking", "requestHeaders"]
);

console.log("🚀 GhostMask Enhanced Edition Loaded");
console.log("📊 Features: VPN Ready | Timezone Spoof | Language Spoof | Enhanced Privacy");